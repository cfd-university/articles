#!/bin/bash

rm -rf build
mkdir -p build

# compile main function and link against header-only library
g++ -g -O0 -Wall -Wextra -I. -DHEADERONLYLIB -o build/headerOnlyLibExample main.cpp

# run
echo "Running header-only library example"
./build/headerOnlyLibExample