#pragma once

#include "linearAlgebraLib/headerOnly/sparseMatrixCSR.hpp"
#include "linearAlgebraLib/headerOnly/vector.hpp"

namespace linearAlgebraLib {

class LinearAlgebraSolverBase {
public:
  LinearAlgebraSolverBase(unsigned numberOfCells) : _coefficientMatrix(numberOfCells, numberOfCells),
    _rightHandSide(numberOfCells) { }
  virtual ~LinearAlgebraSolverBase() = default;

  void setCoefficientMatrix(const SparseMatrixCSR &matrix) {
    _coefficientMatrix = matrix;
  }
  
  void setRightHandSide(const Vector &rhs) {
    _rightHandSide = rhs;
  }
  
  virtual Vector solve(unsigned maxIterations, double convergenceThreshold) = 0;

protected:
  SparseMatrixCSR _coefficientMatrix;
  Vector _rightHandSide;
};

} // namespace linearAlgebraLib