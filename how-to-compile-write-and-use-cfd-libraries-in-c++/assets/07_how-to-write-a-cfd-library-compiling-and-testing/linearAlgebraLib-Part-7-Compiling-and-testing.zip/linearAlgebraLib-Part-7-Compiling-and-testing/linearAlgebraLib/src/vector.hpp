#pragma once

#if defined(WIN32) || defined(_WIN32) || defined(__WIN32__) || defined(__NT__)
  #if defined(COMPILEDLL)
    #define LINEARALGEBRALIB_EXPORT __declspec(dllexport)
  #elif defined(COMPILELIB)
    #define LINEARALGEBRALIB_EXPORT
  #else
    #define LINEARALGEBRALIB_EXPORT __declspec(dllimport)
  #endif
#else
  #define LINEARALGEBRALIB_EXPORT
#endif

#include <iostream>
#include <vector>
#include <cassert>
#include <cmath>

namespace linearAlgebraLib {

class LINEARALGEBRALIB_EXPORT Vector {
public:
  using VectorType = std::vector<double>;

public:
  Vector(const unsigned &size);

  unsigned size() const;

  Vector transpose();
  double getL2Norm() const;

  const double &operator[](unsigned index) const;
  double &operator[](unsigned index);

  Vector operator+(const Vector &other);
  Vector operator-(const Vector &other);

  Vector &operator*(const double &scaleFactor);
  friend Vector operator*(const double &scaleFactor, Vector vector);  
  double operator*(const Vector &other);
  
  friend std::ostream &operator<<(std::ostream &out, const Vector &vector);

private:
  VectorType _vector;
  bool _isRowVector = false;
};

} // namespace linearAlgebraLib