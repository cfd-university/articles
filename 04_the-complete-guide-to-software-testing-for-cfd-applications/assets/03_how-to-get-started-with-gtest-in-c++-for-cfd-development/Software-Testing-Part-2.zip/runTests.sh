#!/bin/bash

# clean up before building
rm -rf build
mkdir -p build

# compile source files into object files
g++ -std=c++20 -I. -I ~/libs/include/ -c -g ./tests/unit/testComplexNumbers.cpp -o ./build/testComplexNumbers.o

# create test executable
g++ -std=c++20 ./build/testComplexNumbers.o -o ./build/testComplexNumbers -L ~/libs/lib -lgtest

# run tests
./build/testComplexNumbers