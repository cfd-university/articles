#!/bin/bash

rm -rf build
mkdir -p build

# compile
g++ -c -g -O0 -std=c++20 -Wall -Wextra -I. -I ~/libs/include ./tests/unit/testParameterReadingJson.cpp -o ./build/testParameterReadingJson.o
g++ -c -g -O0 -std=c++20 -Wall -Wextra -I. -I ~/libs/include ./tests/mainTest.cpp -o ./build/mainTest.o

# link
g++ -o build/parameterReadingTest ./build/mainTest.o ./build/testParameterReadingJson.o -L ~/libs/lib -lgtest -lgmock

# run
./build/parameterReadingTest