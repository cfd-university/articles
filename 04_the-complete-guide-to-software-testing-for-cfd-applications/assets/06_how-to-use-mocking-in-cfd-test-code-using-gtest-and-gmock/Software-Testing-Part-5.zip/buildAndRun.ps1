# clean up before building
Remove-Item .\build -Force -Recurse
New-Item -Name "build" -ItemType "directory"

# compile source files into object files
cl.exe /nologo /EHsc /std:c++20 /I. /I "C:\libraries\include" /c .\tests\unit\testParameterReadingJson.cpp /Fo".\build\testParameterReadingJson.obj"
cl.exe /nologo /EHsc /std:c++20 /I. /I "C:\libraries\include" /c .\tests\mainTest.cpp /Fo".\build\mainTest.obj"

# link object files
cl.exe /nologo /EHsc /std:c++20 .\build\mainTest.obj .\build\testParameterReadingJson.obj /Fe".\build\parameterReadingTest.exe" /link /MACHINE:x64 /LIBPATH:"C:\libraries\lib" gtest.lib gmock.lib

# execute the test
.\build\parameterReadingTest.exe