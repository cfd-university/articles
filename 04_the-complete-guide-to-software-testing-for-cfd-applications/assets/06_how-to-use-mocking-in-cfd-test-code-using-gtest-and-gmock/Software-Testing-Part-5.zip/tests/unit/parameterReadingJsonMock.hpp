#pragma once

#include <filesystem>
#include <fstream>

#include "nlohmann/json.hpp"
#include "gmock/gmock.h"

#include "src/parameterReaderBase.hpp"

class ParameterReaderJsonMock : public ParameterReaderBase<nlohmann::json> {
 public:
  MOCK_METHOD(ParameterReaderBase::FileType, read, (std::filesystem::path), (override));
};