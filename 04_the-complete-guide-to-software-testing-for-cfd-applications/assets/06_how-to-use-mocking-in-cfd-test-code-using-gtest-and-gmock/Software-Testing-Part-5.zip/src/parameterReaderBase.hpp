#pragma once

#include <filesystem>

template <typename StorageType>
class ParameterReaderBase {
public:
  using FileType = StorageType;
  ParameterReaderBase() = default;
  virtual ~ParameterReaderBase() = default;
  virtual FileType read(std::filesystem::path file) = 0;
};