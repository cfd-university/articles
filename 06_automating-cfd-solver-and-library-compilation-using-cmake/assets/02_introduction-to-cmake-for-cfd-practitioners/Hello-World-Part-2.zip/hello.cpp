#include <iostream>

int main() {
  std::cout << "Hello cfd.university" << std::endl;
  return 0;
}