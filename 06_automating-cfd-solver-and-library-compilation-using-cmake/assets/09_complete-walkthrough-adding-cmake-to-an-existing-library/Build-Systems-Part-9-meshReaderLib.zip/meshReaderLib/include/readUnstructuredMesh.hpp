#pragma once

// preprocessor statements
#if defined(WIN32) || defined(_WIN32) || defined(__WIN32__) || defined(__NT__)
  #if defined(COMPILEDLL)
    #define MESHREADERLIB_EXPORT __declspec(dllexport)
  #elif defined(COMPILELIB)
    #define MESHREADERLIB_EXPORT
  #else
    #define MESHREADERLIB_EXPORT __declspec(dllimport)
  #endif
#else
  #define MESHREADERLIB_EXPORT
#endif

// c++ include headers
#include <filesystem>
#include <iostream>
#include <vector>
#include <string>
#include <cmath>
#include <unordered_map>
#include <algorithm>
#include <stdexcept>
#include <tuple>

// third-party include headers
#include "cgnslib.h"

// mesh reading library include headers
#include "meshReaderLib/include/readMeshBase.hpp"
#include "meshReaderLib/include/types.hpp"

// helper classes

/**
 * \class ReadUnstructuredMesh
 * \brief This class reads multi-block unstructured grids from a provided CGNS file.
 * \ingroup meshReader
 *
 * This class provides an implementation of the ReadMeshBase class that reads multi-block unstructured grids from a
 * provided CGNS file. The mesh has to be a 2D mesh, and the grid must be unstructured. It can have an arbitrary number
 * of zones (blocks), but it can only have a single base (which assumes that the mesh does not deform over time).
 * 
 * To set up a basic unstructured mesh reading, use the following example code (and consult the user guide at
 * \ref unstructuredMeshReading for more information):
 *
 * \code
 * #include <filesystem>
 * #include "meshReaderLib/meshReader.hpp"
 * 
 * int main() {
 *   // provide a relative or absolute path to where the CGNS file is located that should be read
 *   auto unstructuredMeshFile = std::filesystem::path("path/to/unstructured/mesh.cgns");
 * 
 *   // create an instance of the unstructured mesh reading class
 *   ReadUnstructuredMesh unstructuredMesh(unstructuredMeshFile);
 * 
 *   // read all unstructured grid properties at once
 *   unstructuredMesh.readMesh();
 * 
 *   // get the coordinates from the unstructured mesh
 *   auto coordinates = unstructuredMesh.getCoordinates();
 * 
 *   // get the internal elements from the unstructured mesh
 *   auto interalElements = unstructuredMesh.getInternalCells();
 * 
 *   // get the interface connectivity from the unstructured mesh
 *   auto interfaceConnectivity = unstructuredMesh.getInterfaceConnectivity();
 * 
 *   // get the boundary condition information
 *   auto boundaryConditions = unstructuredMesh.getBoundaryConditions();
 * 
 *   return 0;
 * }
 * \endcode
 */

class MESHREADERLIB_EXPORT ReadUnstructuredMesh : public ReadMeshBase {
  /// \name Custom types used in this class
  /// @{
public:
  using CoordinateType = typename std::vector<std::vector<std::vector<double>>>;
  using IndexType = std::vector<cgsize_t>;
  using InterfaceConnectivityType = typename std::vector<std::vector<InterfaceConnectivity<IndexType>>>;
  using BoundaryConditionInformationType = typename std::vector<std::vector<BoundaryConditionInformation<IndexType>>>;
  
  using InternalElementConnectivityType = typename std::vector<std::vector<IndexType>>;
  using InterfaceElementConnectivityType = typename std::vector<std::vector<std::vector<IndexType>>>;
  using BoundaryElementConnectivityType = typename std::vector<std::vector<std::vector<IndexType>>>;
  using StartLocationType = typename std::vector<IndexType>;
  using StartLocationForElementConnectivityType = typename std::tuple<std::vector<std::vector<cgsize_t>>,
    std::vector<std::vector<cgsize_t>>, std::vector<std::vector<cgsize_t>>>;
  /// @}

  /// \name Constructors and destructors
  /// @{
public:
  ReadUnstructuredMesh(std::filesystem::path cgnsFilePath);
  /// @}

  /// \name API interface that exposes behaviour to the caller
  /// @{
public:
  void readMesh() override final;
  /// @}

  /// \name Getters and setters
  /// @{
public:
  const CoordinateType& getCoordinates() const { return _coordinates; };
  const InternalElementConnectivityType& getInternalCells() const { return _internalElementConnectivity; };
  const InterfaceConnectivityType getInterfaceConnectivity() const { return _interfaceConnectivity; };
  const BoundaryConditionInformationType& getBoundaryConditions() const { return _boundaryConditions; };
  /// @}

  /// \name Overloaded operators
  /// @{

  /// @}

  /// \name Private or protected implementation details, not exposed to the caller
  /// @{
protected:
  void readCoorinates() override final;
  void readInterfaceConnectivity() override final;
  void readBoundaries() override final;

private:
  void readCellConnectivity();
  StartLocationForElementConnectivityType getStartLocationForElementConnectivity() const;
  /// @}

  /// \name Encapsulated data (private or protected variables)
  /// @{
private:
  CoordinateType _coordinates;
  InterfaceConnectivityType _interfaceConnectivity;
  BoundaryConditionInformationType _boundaryConditions;

  InternalElementConnectivityType _internalElementConnectivity;
  InterfaceElementConnectivityType _interfaceElementConnectivity;
  BoundaryElementConnectivityType _boundaryElementConnectivity;
  /// @}
};
