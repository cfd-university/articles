#pragma once

enum COORDINATE {X = 0, Y};
enum INTERFACE {OWNER = 0, NEIGHBOUR};
enum BC {WALL = 0, INLET, OUTLET, SYMMETRY};