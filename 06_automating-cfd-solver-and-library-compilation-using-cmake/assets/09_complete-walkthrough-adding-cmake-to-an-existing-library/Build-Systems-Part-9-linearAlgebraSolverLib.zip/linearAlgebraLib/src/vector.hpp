#pragma once

// preprocessor statements
#if defined(WIN32) || defined(_WIN32) || defined(__WIN32__) || defined(__NT__)
  #if defined(COMPILEDLL)
    #define LINEARALGEBRALIB_EXPORT __declspec(dllexport)
  #elif defined(COMPILELIB)
    #define LINEARALGEBRALIB_EXPORT
  #else
    #define LINEARALGEBRALIB_EXPORT __declspec(dllimport)
  #endif
#else
  #define LINEARALGEBRALIB_EXPORT
#endif

// c++ include headers
#include <iostream>
#include <vector>
#include <cassert>
#include <cmath>

// third-party include headers

// linear algebra solver library include headers

// helper classes

namespace linearAlgebraLib {

/**
 * \class Vector
 * \brief A vector class with overloaded operators to facilitate arithmetic vector operations
 * \ingroup linearAlgebraComponents
 *
 * This class wraps around a C++ std::vector and extends it with arithmetic operations (addition, subtraction, etc.).
 * It can be accessed as a C++ std::vector<double> and exposes functionality to calculate the L2-norm of the vector. It
 * can also be used together with the \ref SparseMatrixCSR class to perform matrix-vector multiplication. Examples for
 * how to perform basic operations can in the \ref useVector section of the documentation.
 */

class Vector {
  /// \name Custom types used in this class
  /// @{
public:
  using VectorType = std::vector<double>;
  /// @}

  /// \name Constructors and destructors
  /// @{
public:
  LINEARALGEBRALIB_EXPORT Vector(const unsigned &size);
  /// @}

  /// \name API interface that exposes behaviour to the caller
  /// @{
public:
  LINEARALGEBRALIB_EXPORT unsigned size() const;
  LINEARALGEBRALIB_EXPORT Vector transpose();
  LINEARALGEBRALIB_EXPORT double getL2Norm() const;
  /// @}

  /// \name Getters and setters
  /// @{

  /// @}

  /// \name Overloaded operators
  /// @{
public:
  LINEARALGEBRALIB_EXPORT const double &operator[](unsigned index) const;
  LINEARALGEBRALIB_EXPORT double &operator[](unsigned index);

  LINEARALGEBRALIB_EXPORT Vector operator+(const Vector &other);
  LINEARALGEBRALIB_EXPORT Vector operator-(const Vector &other);

  LINEARALGEBRALIB_EXPORT Vector &operator*(const double &scaleFactor);
  LINEARALGEBRALIB_EXPORT friend Vector operator*(const double &scaleFactor, Vector vector);  
  LINEARALGEBRALIB_EXPORT double operator*(const Vector &other);
  
  LINEARALGEBRALIB_EXPORT friend std::ostream &operator<<(std::ostream &out, const Vector &vector);
  /// @}

  /// \name Private or protected implementation details, not exposed to the caller
  /// @{

  /// @}

  /// \name Encapsulated data (private or protected variables)
  /// @{
private:
  VectorType _vector;
  bool _isRowVector = false;
  /// @}
};

} // namespace linearAlgebraLib
