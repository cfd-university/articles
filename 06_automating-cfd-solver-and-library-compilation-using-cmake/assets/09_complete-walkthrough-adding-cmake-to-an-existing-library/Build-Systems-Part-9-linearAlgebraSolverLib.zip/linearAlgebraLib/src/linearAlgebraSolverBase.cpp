// class declaration
#include "linearAlgebraLib/src/linearAlgebraSolverBase.hpp"

namespace linearAlgebraLib {

/// \name Constructors and destructors
/// @{
LinearAlgebraSolverBase::LinearAlgebraSolverBase(unsigned numberOfCells) :
  _coefficientMatrix(numberOfCells, numberOfCells), _rightHandSide(numberOfCells) { }
/// @}

/// \name API interface that exposes behaviour to the caller
/// @{
void LinearAlgebraSolverBase::setCoefficientMatrix(const SparseMatrixCSR &matrix) {
  _coefficientMatrix = matrix;
}

void LinearAlgebraSolverBase::setRightHandSide(const Vector &rhs) {
  _rightHandSide = rhs;
}
/// @}

/// \name Getters and setters
/// @{

/// @}

/// \name Overloaded operators
/// @{

/// @}

/// \name Private or protected implementation details, not exposed to the caller
/// @{

/// @}

/// \name Encapsulated data (private or protected variables)
/// @{

/// @}

} // namespace linearAlgebraLib
