#pragma once

// preprocessor statements
#if defined(WIN32) || defined(_WIN32) || defined(__WIN32__) || defined(__NT__)
  #if defined(COMPILEDLL)
    #define LINEARALGEBRALIB_EXPORT __declspec(dllexport)
  #elif defined(COMPILELIB)
    #define LINEARALGEBRALIB_EXPORT
  #else
    #define LINEARALGEBRALIB_EXPORT __declspec(dllimport)
  #endif
#else
  #define LINEARALGEBRALIB_EXPORT
#endif

// c++ include headers
#include <iostream>

// third-party include headers

// linear algebra solver library include headers
#include "linearAlgebraLib/src/linearAlgebraSolverBase.hpp"
#include "linearAlgebraLib/src/sparseMatrixCSR.hpp"
#include "linearAlgebraLib/src/vector.hpp"

// helper classes

namespace linearAlgebraLib {

/**
 * \class ConjugateGradient
 * \brief Implements the Conjugate Gradient method for solving linear systems.
 * \ingroup linearAlgebraSolvers
 *
 * This class implements the Conjugate Gradient method based on the base class \ref LinearAlgebraSolverBase. The only
 * method implemented is the solve() function. To see how to use this class and how to obtaint he solution vector
 * \f$\mathbf{x}\f$, refer to the \ref useSolver documentation to see an example code usage.
 */

class LINEARALGEBRALIB_EXPORT ConjugateGradient : public LinearAlgebraSolverBase {
  /// \name Custom types used in this class
  /// @{

  /// @}

  /// \name Constructors and destructors
  /// @{
public:
  ConjugateGradient(unsigned numberOfCells);
  /// @}

  /// \name API interface that exposes behaviour to the caller
  /// @{
public:
  virtual Vector solve(unsigned maxIterations, double convergenceThreshold) final override;
  /// @}

  /// \name Getters and setters
  /// @{

  /// @}

  /// \name Overloaded operators
  /// @{

  /// @}

  /// \name Private or protected implementation details, not exposed to the caller
  /// @{

  /// @}

  /// \name Encapsulated data (private or protected variables)
  /// @{

  /// @}
};

} // namespace linearAlgebraLib
