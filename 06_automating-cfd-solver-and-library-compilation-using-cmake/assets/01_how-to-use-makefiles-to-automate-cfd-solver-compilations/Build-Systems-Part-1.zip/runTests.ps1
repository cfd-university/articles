# clean up before building
Remove-Item .\build -Force -Recurse
New-Item -Name "build" -ItemType "directory"

# compile source files into object files
cl.exe /nologo /EHsc /std:c++20 /Zi /I. /I"C:\libraries\include\" /c .\tests\unit\testComplexNumbers.cpp /Fo".\build\testComplexNumbers.obj"

# create test executable
cl.exe /nologo /EHsc /std:c++20 /Zi .\build\testComplexNumbers.obj /Fe".\build\testComplexNumbers.exe" /link /MACHINE:x64 /LIBPATH:"C:\libraries\lib" gtest.lib

# run tests
.\build\testComplexNumbers.exe