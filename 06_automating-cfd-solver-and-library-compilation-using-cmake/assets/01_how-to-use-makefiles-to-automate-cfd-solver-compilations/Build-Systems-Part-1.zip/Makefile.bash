### name of application
APP_NAME = testComplexNumbers

### Specifying the compiler
CXX = g++

### Specifying compiler flags
CXXFLAGS = -c -std=c++20 -I. -I ~/libs/include/

### Specifying linker flags
LXXFLAGS = -L ~/libs/lib -lgtest

### Specifying all source files
SRC = tests/unit/testComplexNumbers.cpp

### Create list of object files based on source files
OBJ = $(subst .cpp,.o,$(SRC))

# Create default target
all: clean init debug run

# Create release build
release: CXXFLAGS += -Ofast -DNDEBUG
release: init $(APP_NAME)

# Create debug build
debug: CXXFLAGS += -g -O0 -Wall -Wextra -Wpedantic
debug: init $(APP_NAME)

# Create test executable
$(APP_NAME): $(OBJ)
	$(CXX) $^ $(LXXFLAGS) -o build/$@

%.o: %.cpp
	$(CXX) $(CXXFLAGS) $< -o $@

.PHONY: init
init:
	mkdir -p build

.PHONY: clean
clean:
	rm -rf $(OBJ) build/$(APP_NAME)

.PHONY: run
run:
	./build/$(APP_NAME)
