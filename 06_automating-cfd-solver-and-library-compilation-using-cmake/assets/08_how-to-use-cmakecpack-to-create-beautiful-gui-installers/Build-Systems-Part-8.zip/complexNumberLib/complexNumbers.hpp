#pragma once

// preprocessor statements
#if defined(WIN32) || defined(_WIN32) || defined(__WIN32__) || defined(__NT__)
  #if defined(COMPILEDLL)
    #define EXPORT __declspec(dllexport)
  #elif defined(COMPILELIB)
    #define EXPORT
  #else
    #define EXPORT __declspec(dllimport)
  #endif
#else
  #define EXPORT
#endif

// c++ include headers
#include <iostream>
#include <cmath>
#include <stdexcept>
#include <limits>

// third-party include headers

// include headers from current project

// helper classes

// namespace declaration go here

/**
 * \class ComplexNumber
 * \brief A class for complex number arithmetic and manipulation
 *
 * This class implements complex numbers to allow for complex number arithmetic.
 *
 * The following demonstrates some example for how this class could be used:
 * \code
 * #include <cassert>
 * #include "complexNumberLib/complexNumber.hpp"
 * 
 * int main() {
 *   ComplexNumber a(3.0, 4.0);
 *   ComplexNumber b(1.8, 5.3);
 * 
 *   assert(a.magnitude() == 5.0);
 * 
 *   a.conjugate();
 *   assert(a.Re() == 3.0);
 *   assert(a.Im() == -4.0);
 * 
 *   auto c1 = a + b;
 *   auto c2 = a - b;
 *   auto c2 = a * b;
 *   auto c2 = a / b;
 * 
 *   return 0;
 * }
 * \endcode
 */

class ComplexNumber {
public:
  /// \name Custom types used in this class
  /// @{

  /// @}

public:
  /// \name Constructors and destructors
  /// @{
  EXPORT ComplexNumber(double real, double imaginary);
	EXPORT ~ComplexNumber();
  /// @}

public:
  /// \name API interface that exposes behaviour to the caller
  /// @{
  EXPORT void conjugate();
  EXPORT double magnitude() const;
  /// @}

public:
  /// \name Getters and setters
  /// @{
  EXPORT double Re() const;
	EXPORT double Im() const;
  EXPORT void setRe(double real);
  EXPORT void setIm(double imaginary);
  /// @}

public:
  /// \name Overloaded operators
  /// @{
  EXPORT ComplexNumber operator+(const ComplexNumber &other);
  EXPORT ComplexNumber operator-(const ComplexNumber &other);
  EXPORT ComplexNumber operator*(const ComplexNumber &other);
  EXPORT ComplexNumber operator/(const ComplexNumber &other);
  EXPORT friend std::ostream &operator<<(std::ostream &os, const ComplexNumber &c);
  /// @}

private:
  /// \name Private or protected implementation details, not exposed to the caller
  /// @{
  void isNan(double real, double imaginary) const;
  /// @}

private:
  /// \name Encapsulated data (private or protected variables)
  /// @{
  double _real;
	double _imaginary;
  /// @}
};
