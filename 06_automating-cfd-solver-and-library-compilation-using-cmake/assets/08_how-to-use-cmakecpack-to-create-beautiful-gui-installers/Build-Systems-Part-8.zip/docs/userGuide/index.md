\page mainpage A simple C++ library for dealing with complex numbers

This is a simple and lightweight library that deals with complex number arithmetic.

## Table of contents

- [Introduction](\ref introduction)
- [Installation](\ref installation)
- [Usage](\ref usage)