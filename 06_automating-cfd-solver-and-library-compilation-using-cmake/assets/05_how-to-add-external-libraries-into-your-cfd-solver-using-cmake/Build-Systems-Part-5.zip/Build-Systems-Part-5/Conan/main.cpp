#include <Imath/ImathMatrix.h>
#include <Imath/ImathVec.h>
#include <iostream>
#include <numbers>

int
main() {
  // Vertices of a triangle
  Imath::V3f v1(1.0, 0.0, 0.0);
  Imath::V3f v2(1.0, 1.0, 0.0);
  Imath::V3f v3(2.0, 0.0, 0.0);

  // Rotation matrix
  Imath::M44f m;
  m.makeIdentity();
  m.rotate(Imath::V3f(0.0, 0.0, std::numbers::pi/2.0));

  // Rotated vertices
  Imath::V3f v1Rotated, v2Rotated, v3Rotated;
  m.multVecMatrix(v1, v1Rotated);
  m.multVecMatrix(v2, v2Rotated);
  m.multVecMatrix(v3, v3Rotated);

  // Print rotated vertices
  std::cout << "v1Rotated: " << v1Rotated << std::endl;
  std::cout << "v2Rotated: " << v2Rotated << std::endl;
  std::cout << "v3Rotated: " << v3Rotated << std::endl;

  return 0;
}