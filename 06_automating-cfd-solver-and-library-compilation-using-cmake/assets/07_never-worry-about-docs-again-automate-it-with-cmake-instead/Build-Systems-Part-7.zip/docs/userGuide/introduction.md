\page introduction Introduction

A simple C++ library to work with complex numbers. This libraru was developed to showcase how to integrate `Doxygen` with `cmake` to automatically generate and deploy the latest documentation. Read the full write-up on how to automate your documentation generation on [cfd.university](https://cfd.university/learn).