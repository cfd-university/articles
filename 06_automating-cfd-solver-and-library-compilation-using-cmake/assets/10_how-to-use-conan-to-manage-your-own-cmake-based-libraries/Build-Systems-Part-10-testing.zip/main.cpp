#include <iostream>

#include "linearAlgebraLib/linearAlgebraLib.hpp"
#include "meshReaderLib/meshReader.hpp"

int main() {

  // sanity check that linearAlgebraLib is working and found
  linearAlgebraLib::SparseMatrixCSR matrix(3, 3);
  matrix.set(0, 0, 1.0); matrix.set(0, 1, 2.0); matrix.set(0, 2, 0.0);
  matrix.set(1, 0, 2.0); matrix.set(1, 1, 1.0); matrix.set(1, 2, 2.0);
  matrix.set(2, 0, 0.0); matrix.set(2, 1, 2.0); matrix.set(2, 2, 1.0);

  linearAlgebraLib::Vector vector(3);
  vector[0] = 1.0; vector[1] = 0.0; vector[2] = 1.0;

  std::cout << "Testing linearAlgebraLib:\n" << matrix * vector << std::endl;

  // sanity check that meshReaderLib is working and found
  ReadStructuredMesh mesh("../mesh/structured2D.cgns");
  mesh.readMesh();
  auto coordinates = mesh.getCoordinates();

  // print first 5 coordinates
  std::cout << "\nTesting meshReaderLib:\nX | Y " << std::endl;
  std::cout << "------" << std::endl;
  std::cout << coordinates[0][0][0][COORDINATE::X] << " | " << coordinates[0][0][0][COORDINATE::Y] << std::endl;
  std::cout << coordinates[0][0][1][COORDINATE::X] << " | " << coordinates[0][0][1][COORDINATE::Y] << std::endl;
  std::cout << coordinates[0][0][2][COORDINATE::X] << " | " << coordinates[0][0][2][COORDINATE::Y] << std::endl;
  std::cout << coordinates[0][0][3][COORDINATE::X] << " | " << coordinates[0][0][3][COORDINATE::Y] << std::endl;
  std::cout << coordinates[0][0][4][COORDINATE::X] << " | " << coordinates[0][0][4][COORDINATE::Y] << std::endl;

  return 0;
}