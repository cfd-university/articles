#pragma once

// preprocessor statements
#if defined(WIN32) || defined(_WIN32) || defined(__WIN32__) || defined(__NT__)
  #if defined(COMPILEDLL)
    #define LINEARALGEBRALIB_EXPORT __declspec(dllexport)
  #elif defined(COMPILELIB)
    #define LINEARALGEBRALIB_EXPORT
  #else
    #define LINEARALGEBRALIB_EXPORT __declspec(dllimport)
  #endif
#else
  #define LINEARALGEBRALIB_EXPORT
#endif

// c++ include headers
#include <iostream>
#include <algorithm>
#include <vector>
#include <cassert>

// third-party include headers

// linear algebra solver library include headers
#include "linearAlgebraLib/src/vector.hpp"

// helper classes

namespace linearAlgebraLib {

/**
 * \class SparseMatrixCSR
 * \brief A matrix class with overloaded operators to facilitate arithmetic matrix operations
 * \ingroup linearAlgebraComponents
 *
 * This class implements a 2D sparse matrix using the Compressed Sparse Row (CSR) format. The CSR format, as excellently
 * discussed by <a href="https://matteding.github.io/2019/04/25/sparse-matrices/" target="_blank">Matt Eding</a>, is
 * used to store only non-zero elements in the matrix which reduces memory consumption significantly (and, in fact,
 * makes large CFD calculations possible in the first place). To see how to use this class, refer to the \ref useMatrix
 * section in the documentation.
 */

class SparseMatrixCSR {
  /// \name Custom types used in this class
  /// @{

  /// @}

  /// \name Constructors and destructors
  /// @{
public:
  LINEARALGEBRALIB_EXPORT SparseMatrixCSR(unsigned rows, unsigned _columns);
  /// @}

  /// \name API interface that exposes behaviour to the caller
  /// @{

  /// @}

  /// \name Getters and setters
  /// @{
public:
  LINEARALGEBRALIB_EXPORT void set(unsigned row, unsigned column, double value);
  LINEARALGEBRALIB_EXPORT double get(unsigned row, unsigned column) const;

  LINEARALGEBRALIB_EXPORT unsigned getNumberOfRows() const;
  LINEARALGEBRALIB_EXPORT unsigned getNumberOfColumns() const;
  /// @}

  /// \name Overloaded operators
  /// @{
public:
  LINEARALGEBRALIB_EXPORT Vector operator*(const Vector& rhs);
  LINEARALGEBRALIB_EXPORT friend SparseMatrixCSR operator*(const double &scaleFactor, const SparseMatrixCSR &matrix);
  LINEARALGEBRALIB_EXPORT friend std::ostream &operator<<(std::ostream &os, const SparseMatrixCSR &rhs);
  /// @}

  /// \name Private or protected implementation details, not exposed to the caller
  /// @{

  /// @}

  /// \name Encapsulated data (private or protected variables)
  /// @{
private:
  std::vector<double> _values;
  std::vector<unsigned> _columns;
  std::vector<unsigned> _rows;
  unsigned _numberOfRows;
  unsigned _numberOfColumns;
  /// @}
};

} // namespace linearAlgebraLib
