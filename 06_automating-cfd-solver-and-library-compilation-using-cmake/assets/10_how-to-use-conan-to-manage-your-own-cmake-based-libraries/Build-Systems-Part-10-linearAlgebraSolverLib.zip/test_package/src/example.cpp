#include <vector>
#include <string>

#include "linearAlgebraLib/linearAlgebraLib.hpp"

int main() {
  linearAlgebraLib::SparseMatrixCSR matrix(3, 3);
  return 0;
}
