#pragma once

// preprocessor statements
#if defined(WIN32) || defined(_WIN32) || defined(__WIN32__) || defined(__NT__)
  #if defined(COMPILEDLL)
    #define MESHREADERLIB_EXPORT __declspec(dllexport)
  #elif defined(COMPILELIB)
    #define MESHREADERLIB_EXPORT
  #else
    #define MESHREADERLIB_EXPORT __declspec(dllimport)
  #endif
#else
  #define MESHREADERLIB_EXPORT
#endif

// c++ include headers
#include <filesystem>
#include <iostream>
#include <vector>
#include <array>
#include <unordered_map>
#include <string>
#include <cmath>

// third-party include headers
#include "cgnslib.h"

// mesh reading library include headers
#include "meshReaderLib/include/readMeshBase.hpp"
#include "meshReaderLib/include/types.hpp"

// helper classes

/**
 * \class ReadStructuredMesh
 * \brief This class reads multi-block structured grids from a provided CGNS file.
 * \ingroup meshReader
 *
 * This class provides an implementation of the ReadMeshBase class that reads multi-block structured grids from a
 * provided CGNS file. The mesh has to be a 2D mesh, and the grid must be structured. It can have an arbitrary number of
 * zones (blocks), but it can only have a single base (which assumes that the mesh does not deform over time).
 * 
 * To set up a basic structured mesh reading, use the following example code (and consult the user guide at
 * \ref structuredMeshReading for more information):
 * \code
 * #include <filesystem>
 * #include "meshReaderLib/meshReader.hpp"
 *  
 * int main() {
 *   // provide a relative or absolute path to where the CGNS file is located that should be read
 *   auto structuredMeshFile = std::filesystem::path("path/to/structured/mesh.cgns");
 *  
 *   // create an instance of the structured mesh reading class
 *   ReadStructuredMesh structuredMesh(structuredMeshFile);
 *  
 *   // read all structured grid properties at once
 *   structuredMesh.readMesh();
 *  
 *   // get the coordinates from the structured mesh
 *   auto coordinates = structuredMesh.getCoordinates();
 *  
 *   // get the interface connectivity from the structured mesh
 *   auto interfaceConnectivity = structuredMesh.getInterfaceConnectivity();
 * 
 *   // get the boundary condition information
 *   auto boundaryConditions = structuredMesh.getBoundaryConditions();
 * 
 *   return 0;
 * }
 * \endcode
 */

class MESHREADERLIB_EXPORT ReadStructuredMesh : public ReadMeshBase {
  /// \name Custom types used in this class
  /// @{
public:
  using ZoneType = typename std::vector<std::vector<cgsize_t>>;
  using CoordinateType = typename std::vector<std::vector<std::vector<std::vector<double>>>>;
  using IndexType = typename std::array<unsigned, 2>;
  using InterfaceConnectivityType = typename std::vector<InterfaceConnectivity<IndexType>>;
  using BoundaryConditionInformationType = typename std::vector<std::vector<BoundaryConditionInformation<IndexType>>>;
  /// @}

  /// \name Constructors and destructors
  /// @{
public:
  ReadStructuredMesh(std::filesystem::path cgnsFilePath);
  /// @}

  /// \name API interface that exposes behaviour to the caller
  /// @{
public:
  void readMesh() override final;
  /// @}

  /// \name Getters and setters
  /// @{
public:
  const CoordinateType& getCoordinates() const { return _coordinates; }
  const InterfaceConnectivityType& getInterfaceConnectivity() const { return _interfaceConnectivity; }
  const BoundaryConditionInformationType& getBoundaryConditions() const { return _boundaryConditions; }
  /// @}

  /// \name Overloaded operators
  /// @{

  /// @}

  /// \name Private or protected implementation details, not exposed to the caller
  /// @{
protected:
  void readCoorinates() override final;
  void readInterfaceConnectivity() override final;
  void readBoundaries() override final;
  /// @}

  /// \name Encapsulated data (private or protected variables)
  /// @{
private:
  CoordinateType _coordinates;
  InterfaceConnectivityType _interfaceConnectivity;
  BoundaryConditionInformationType _boundaryConditions;
  /// @}
};
