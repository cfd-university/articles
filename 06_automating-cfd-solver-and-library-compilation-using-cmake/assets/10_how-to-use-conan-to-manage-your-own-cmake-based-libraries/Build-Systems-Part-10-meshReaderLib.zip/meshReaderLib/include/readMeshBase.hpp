#pragma once

// preprocessor statements
#if defined(WIN32) || defined(_WIN32) || defined(__WIN32__) || defined(__NT__)
  #if defined(COMPILEDLL)
    #define MESHREADERLIB_EXPORT __declspec(dllexport)
  #elif defined(COMPILELIB)
    #define MESHREADERLIB_EXPORT
  #else
    #define MESHREADERLIB_EXPORT __declspec(dllimport)
  #endif
#else
  #define MESHREADERLIB_EXPORT
#endif

// c++ include headers
#include <iostream>
#include <filesystem>
#include <cassert>
#include <vector>
#include <array>
#include <unordered_map>

// third-party include headers
#include "cgnslib.h"

// mesh reading library include headers
#include "meshReaderLib/include/types.hpp"

// helper classes
template<typename IndexType>
struct MESHREADERLIB_EXPORT InterfaceConnectivity {
  std::array<int, 2> zones;
  std::vector<IndexType> ownerIndex;
  std::vector<IndexType> neighbourIndex;
};

template<typename IndexType>
struct MESHREADERLIB_EXPORT BoundaryConditionInformation {
  std::string boundaryName;
  unsigned boundaryType;
  std::vector<IndexType> indices;
};

/**
 * \class ReadMeshBase
 * \brief Base class for implementing a CGNS-based mesh reader
 * \ingroup meshReader
 *
 * This class exposes an interface for classes to derive from to read either structured or unstructured grids using the
 * CGNS file format. 
 */

class MESHREADERLIB_EXPORT ReadMeshBase {
  /// \name Custom types used in this class
  /// @{
public:
  using ZoneType = typename std::vector<std::vector<cgsize_t>>;
  /// @}

  /// \name Constructors and destructors
  /// @{
public:
  ReadMeshBase(std::filesystem::path cgnsFilePath);
  ~ReadMeshBase();
  /// @}

  /// \name API interface that exposes behaviour to the caller
  /// @{
public:
  virtual void readMesh() = 0;
  /// @}

  /// \name Getters and setters
  /// @{

  /// @}

  /// \name Overloaded operators
  /// @{

  /// @}

  /// \name Private or protected implementation details, not exposed to the caller
  /// @{
protected:
  void readBases();
  void readZones(ZoneType_t zoneType);
  void createBoundaryNameLookupTable();

  virtual void readCoorinates() = 0;
  virtual void readInterfaceConnectivity() = 0;
  virtual void readBoundaries() = 0;
  unsigned getBoundaryConditionID(BCType_t bcType);
  /// @}

  /// \name Encapsulated data (private or protected variables)
  /// @{
protected:
  std::filesystem::path _cgnsFilePath;
  int _numberOfZones = 0;
  int _numberOfBoundaries = 0;
  int _fileIndex = 0;

  ZoneType _zoneSizesMax, _zoneSizesMin;
  std::unordered_map<std::string, cgsize_t> _zoneNamesMap;
  std::unordered_map<std::string, BCType_t> _boundaryConditionMap;
  /// @}
};
