\page introduction Introduction

When it comes to reading a computational mesh, there are several file formats that offer a varying degree of support. Most are segregated into either structured or unstructured grids-only format, and thus can only be used for a subset of grids.

The [CFD General Notation System](https://cgns.github.io/) (CGNS) format is a dedicated file format that can store information pertinent to CFD simulations, most importantly, the mesh itself. It has support for multi-block structured and unstructured grids, parallel file input and output, it can store arbitrary polyhedra as cell types, and it can store the CFD solution itself.

The CGNS file format makes use of [HDF5](https://www.hdfgroup.org/solutions/hdf5/), which efficiently stores the grid information in binary form. It is used in many scientific applications where data compression is required due to the size of the data stored. CFD is no different in that large file sizes for computational grids are common for industrial-scale problems. The HDF5 compression and storage routines have proven themselves to be the best choice in this case.

This library, then, provides a convenient wrapper around the CGNS library's API calls, to read both structured and unstructured grids. These are returned via a few getter functions that return information on the grid points, interfaces, and boundary conditions.