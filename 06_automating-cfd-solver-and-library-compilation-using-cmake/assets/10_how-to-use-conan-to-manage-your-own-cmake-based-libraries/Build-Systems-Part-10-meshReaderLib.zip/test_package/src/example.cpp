#include <vector>
#include <string>

#include "meshReaderLib/meshReader.hpp"

int main() {
  ReadStructuredMesh structuredMesh("structured2D.cgns");
  structuredMesh.readMesh();
  return 0;
}
