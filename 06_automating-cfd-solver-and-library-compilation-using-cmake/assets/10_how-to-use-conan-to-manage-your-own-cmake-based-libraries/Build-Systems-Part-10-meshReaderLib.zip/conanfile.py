from conan import ConanFile
from conan.tools.cmake import CMakeToolchain, CMake, cmake_layout, CMakeDeps


class meshReaderLibRecipe(ConanFile):
    name = "meshreaderlib"
    version = "1.0"
    package_type = "library"

    # Optional metadata
    license = "MIT"
    author = "Tom-Robin Teschner"
    url = "https://cfd.university"
    description = "A mesh reading library for multi-block structured and unstructured grids using the CGNS file format."
    topics = ("cfd", "mesh", "grids", "cgns", "structured", "unstructured")

    # Binary configuration
    settings = "os", "compiler", "build_type", "arch"
    options = {
        "shared": [True, False],
        "fPIC": [True, False],
        "with_gtest": [True, False],
        "with_doxygen": [True, False]
    }
    default_options = {
        "shared": False,
        "fPIC": True,
        "with_gtest": False,
        "with_doxygen": False
    }

    # Sources are located in the same place as this recipe, copy them to the recipe
    exports_sources = "CMakeLists.txt", "cmake/*", "docs/*", "tests/*", "mesh/*", "meshReaderLib/*"

    def config_options(self):
        if self.settings.os == "Windows":
            self.options.rm_safe("fPIC")

    def configure(self):
        if self.options.shared:
            self.options.rm_safe("fPIC")

    def layout(self):
        cmake_layout(self)

    def requirements(self):
        self.requires("cgns/4.3.0", transitive_headers=True)
        if self.options.with_gtest:
            self.requires("gtest/1.14.0", transitive_headers=True)
    
    def build_requirements(self):        
        if self.options.with_doxygen:
            self.requires("doxygen/1.9.4")

    def generate(self):
        deps = CMakeDeps(self)
        deps.generate()
        tc = CMakeToolchain(self)
        tc.variables["ENABLE_SHARED"] = self.options.shared
        tc.variables["ENABLE_TESTS"] = self.options.with_gtest
        tc.variables["BUILD_DOCS"] = self.options.with_doxygen
        tc.generate()

    def build(self):
        cmake = CMake(self)
        cmake.configure()
        cmake.build()

    def package(self):
        cmake = CMake(self)
        cmake.install()

    def package_info(self):
        # set global project settings
        self.cpp_info.set_property("cmake_file_name", "meshReaderLib")
        self.cpp_info.set_property("cmake_target_name", "meshReaderLib::meshReaderLib")

        # handle Window's amazing naming convention for debug libraries
        if self.settings.os == "Windows" and self.settings.build_type == "Debug":
            self.cpp_info.libs = ["meshReaderLibd"]
        else:
            self.cpp_info.libs = ["meshReaderLib"]

        # add pre-processor definitions to resolve __declspec()s correctly on Windows for shared libraries
        if self.settings.os == "Windows":
            if self.options.shared:
                self.cpp_info.defines = ["COMPILEDLL"]
            else:
                self.cpp_info.defines = ["COMPILELIB"]

        # link against dependencies
        self.cpp_info.requires = ["cgns::cgns"]

        if self.options.with_gtest:
            self.cpp_info.requires.append("gtest::gtest")