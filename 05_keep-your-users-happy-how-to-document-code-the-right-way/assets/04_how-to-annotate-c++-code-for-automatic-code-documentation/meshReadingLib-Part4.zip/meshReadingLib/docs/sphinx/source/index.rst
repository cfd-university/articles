.. meshReaderLib documentation master file, created by
   sphinx-quickstart on Mon Apr  8 05:36:28 2024.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.

meshReaderLib user-guide
========================

This is a C++ library that is capable of reading 2D structured and
unstructured grids, which may or may not be distributed into different
blocks (i.e. the grids may be represented as multi-block structured and
unstructured grids).

.. toctree::
   :maxdepth: 5
   :caption: Contents:

   introduction
   installation
   usage

Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`
