set-up
======
create docs/ directory, then create configuration file with

``doxygen -g``

This will create the default ``Doxyfile``

Changes to be made
******************

PROJECT_NAME
TAB_SIZE = 2
PROJECT_LOGO           = figures/logo.png
OUTPUT_DIRECTORY       = output
INPUT
  INPUT                  = ../src/
  INPUT                 += manual/
  INPUT                 += manual/userGuide
  INPUT                 += manual/developerGuide
RECURSIVE              = YES
USE_MDFILE_AS_MAINPAGE = manual/index.md
USE_MATHJAX            = YES
MATHJAX_RELPATH        = https://cdn.jsdelivr.net/npm/mathjax@2 (or use version 3?)
GENERATE_TREEVIEW      = YES
HAVE_DOT               = YES (and install dot from https://www.graphviz.org/, adding it to path during installation)
HTML_COLORSTYLE        = LIGHT
HTML_EXTRA_STYLESHEET  = doxygen-awesome-css-2.3.2/doxygen-awesome.css
HTML_EXTRA_STYLESHEET += doxygen-awesome-css-2.3.2/doxygen-awesome-sidebar-only.css

Running doxygen
***************

Once changes are done, run doxygen with the following command:

``doxygen Doxyfile``

This will create an HTML output in the `output/html` directory. Open the `index.html` to inspect the generated HTLM output