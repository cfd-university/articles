\page mainpage CGNS-based mesh reading library for multi-block structured and unstructured grids

This is a C++ library that is capable of reading 2D structured and unstructured grids, which may or may not be distributed into different blocks (i.e. the grids may be represented as multi-block structured and unstructured grids).

## Table of contents

- [Introduction](\ref introduction)
- [Installation](\ref installation)
- [Usage](\ref usage)