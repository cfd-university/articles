#pragma once

// preprocessor statements
#if defined(WIN32) || defined(_WIN32) || defined(__WIN32__) || defined(__NT__)
  #if defined(COMPILEDLL)
    #define LINEARALGEBRALIB_EXPORT __declspec(dllexport)
  #elif defined(COMPILELIB)
    #define LINEARALGEBRALIB_EXPORT
  #else
    #define LINEARALGEBRALIB_EXPORT __declspec(dllimport)
  #endif
#else
  #define LINEARALGEBRALIB_EXPORT
#endif

// c++ include headers

// third-party include headers

// linear algebra solver library include headers
#include "linearAlgebraLib/src/sparseMatrixCSR.hpp"
#include "linearAlgebraLib/src/vector.hpp"

// helper classes

namespace linearAlgebraLib {

/**
 * \class LinearAlgebraSolverBase
 * \brief A class defining an interface for linear algebra solvers to implement
 * \ingroup linearAlgebraSolvers
 *
 * This class defines the interface for a linear algebra solver to implement. Here, the linear algebra solver will be
 * used to solve the linear system of equations of the form \f$\mathbf{Ax}=\mathbf{b}\f$. Therefore, it exposes
 * functionality to set the coefficient matrix \f$\mathbf{A}\f$ and the right hand side vector \f$\mathbf{b}\f$, while
 * the solver will return the solution vector \f$\mathbf{x}\f$ using the solve() method.
 */

class LINEARALGEBRALIB_EXPORT LinearAlgebraSolverBase {
  /// \name Custom types used in this class
  /// @{

  /// @}

  /// \name Constructors and destructors
  /// @{
public:
  LinearAlgebraSolverBase(unsigned numberOfCells);
  virtual ~LinearAlgebraSolverBase() = default;
  /// @}

  /// \name API interface that exposes behaviour to the caller
  /// @{
public:
  void setCoefficientMatrix(const SparseMatrixCSR &matrix);
  void setRightHandSide(const Vector &rhs);
  virtual Vector solve(unsigned maxIterations, double convergenceThreshold) = 0;
  /// @}

  /// \name Getters and setters
  /// @{

  /// @}

  /// \name Overloaded operators
  /// @{

  /// @}

  /// \name Private or protected implementation details, not exposed to the caller
  /// @{
protected:
  SparseMatrixCSR _coefficientMatrix;
  Vector _rightHandSide;
  /// @}

  /// \name Encapsulated data (private or protected variables)
  /// @{

  /// @}
};

} // namespace linearAlgebraLib
