var indexSectionsWithContent =
{
  0: "clsv",
  1: "clsv",
  2: "l"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "pages"
};

var indexSectionLabels =
{
  0: "All",
  1: "Classes",
  2: "Pages"
};

