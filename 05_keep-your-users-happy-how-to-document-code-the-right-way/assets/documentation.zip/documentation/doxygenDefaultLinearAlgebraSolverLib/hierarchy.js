var hierarchy =
[
    [ "linearAlgebraLib::LinearAlgebraSolverBase", "classlinear_algebra_lib_1_1_linear_algebra_solver_base.html", [
      [ "linearAlgebraLib::ConjugateGradient", "classlinear_algebra_lib_1_1_conjugate_gradient.html", null ]
    ] ],
    [ "linearAlgebraLib::SparseMatrixCSR", "classlinear_algebra_lib_1_1_sparse_matrix_c_s_r.html", null ],
    [ "linearAlgebraLib::Vector", "classlinear_algebra_lib_1_1_vector.html", null ]
];