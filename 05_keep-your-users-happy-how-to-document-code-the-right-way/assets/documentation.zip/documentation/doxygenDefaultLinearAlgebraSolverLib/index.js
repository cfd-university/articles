var index =
[
    [ "Introduction", "index.html#autotoc_md1", null ],
    [ "Installation", "index.html#autotoc_md2", [
      [ "Windows", "index.html#autotoc_md3", [
        [ "Single executable (tests + library)", "index.html#autotoc_md4", null ],
        [ "Tests with separate static mesh reader library", "index.html#autotoc_md5", null ],
        [ "Tests with separate dynamic mesh reader library", "index.html#autotoc_md6", null ]
      ] ],
      [ "UNIX (macOS, Ubuntu, etc.)", "index.html#autotoc_md7", [
        [ "Single executable (tests + library)", "index.html#autotoc_md8", null ],
        [ "Tests with separate static mesh reader library", "index.html#autotoc_md9", null ],
        [ "Tests with separate dynamic mesh reader library", "index.html#autotoc_md10", null ]
      ] ]
    ] ],
    [ "Usage", "index.html#autotoc_md11", [
      [ "Creating a matrix", "index.html#useMatrix", null ],
      [ "Creating a vector", "index.html#useVector", null ],
      [ "Creating a linear system of equations", "index.html#useSolver", null ]
    ] ],
    [ "References", "index.html#autotoc_md12", null ]
];