var annotated_dup =
[
    [ "linearAlgebraLib", null, [
      [ "ConjugateGradient", "classlinear_algebra_lib_1_1_conjugate_gradient.html", null ],
      [ "LinearAlgebraSolverBase", "classlinear_algebra_lib_1_1_linear_algebra_solver_base.html", null ],
      [ "SparseMatrixCSR", "classlinear_algebra_lib_1_1_sparse_matrix_c_s_r.html", null ],
      [ "Vector", "classlinear_algebra_lib_1_1_vector.html", null ]
    ] ]
];