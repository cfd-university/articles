var hierarchy =
[
    [ "BoundaryConditionInformation< IndexType >", "struct_boundary_condition_information.html", null ],
    [ "InterfaceConnectivity< IndexType >", "struct_interface_connectivity.html", null ],
    [ "ReadMeshBase", "class_read_mesh_base.html", [
      [ "ReadStructuredMesh", "class_read_structured_mesh.html", null ],
      [ "ReadUnstructuredMesh", "class_read_unstructured_mesh.html", null ]
    ] ]
];