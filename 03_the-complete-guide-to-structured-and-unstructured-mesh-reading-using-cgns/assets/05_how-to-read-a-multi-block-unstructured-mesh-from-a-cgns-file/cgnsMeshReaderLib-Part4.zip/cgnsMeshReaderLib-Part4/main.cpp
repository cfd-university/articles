#include <iostream>
#include <filesystem>
#include <cmath>
#include <string>

#include "meshReaderLib/meshReader.hpp"

int main() {
  auto structuredMeshPathFamily = std::filesystem::path("mesh/structured2D.cgns");
  ReadStructuredMesh structuredMeshFamily(structuredMeshPathFamily);
  structuredMeshFamily.readMesh();

  std::cout << "structured mesh was read" << std::endl;

  auto unstructuredMeshPathNoFamily = std::filesystem::path("mesh/unstructured2DNoFamily.cgns");
  ReadUnstructuredMesh unstructuredMeshNoFamily(unstructuredMeshPathNoFamily);
  unstructuredMeshNoFamily.readMesh();

  std::cout << "unstructured mesh was read" << std::endl;

  return 0;
}