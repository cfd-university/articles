#include <iostream>
#include <Eigen/Eigen>
#include <vector>

int main() {
    // create a std::vector with 9 entries
    std::vector<double> vec = {1.0, 2.0, 3.0, 4.0, 5.0, 6.0, 7.0, 8.0, 9.0};

    // convert to Eigen vector through Eigen::Map
    Eigen::Map<Eigen::VectorXd> eigen_vec(vec.data(), vec.size());

    // or, create 3 by 3 matrix directly
    Eigen::Map<Eigen::MatrixXd> eigen_mat(vec.data(), 3, 3);

    // print the Eigen vectors and matrices
    std::cout << "Eigen vector:\n" << eigen_vec.transpose() << std::endl;
    std::cout << "\nEigen matrix (not expected order?!):\n" << eigen_mat << std::endl;
    
    // specify storage order of matrix explicitly, requires full template parameters
    Eigen::Map<Eigen::Matrix<double, Eigen::Dynamic, Eigen::Dynamic, Eigen::RowMajor>> eigen_mat2(vec.data(), 3, 3);   
    std::cout << "\nEigen matrix (expected order):\n" << eigen_mat2 << std::endl;

    // let's make sure no data was copied by comparing storage addresses
    std::cout << "\nstd::vector  address: " << &vec[0] << std::endl;
    std::cout << "Eigen vector address: " << &eigen_vec(0) << std::endl;
    std::cout << "Eigen matrix address: " << &eigen_mat(0,0) << std::endl;

    // modifying Eigen will modify std::vector
    eigen_vec(0) = 10.0;
    eigen_mat(1,1) = 20.0;
    eigen_mat2(2,2) = 30.0;

    std::cout << "\nstd::vector:  ";
    for (const auto& v : vec) std::cout << v << " ";
    std::cout << std::endl;

    std::cout << "Eigen vector: " << eigen_vec.transpose() << std::endl;
    std::cout << "\nEigen matrix:\n" << eigen_mat << std::endl;
    std::cout << "\nEigen matrix:\n" << eigen_mat2 << std::endl;

    return 0;
}