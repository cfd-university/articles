#include <iostream>
#include <Eigen/Eigen>

int main() {
    // 2d structured grid parameters
    const auto numX = 5;
    const auto numY = 5;
    const auto numGP = 2; // number of ghost points

    // domain start and end
    const auto xStart = 0.0; const auto xEnd = 1.0;
    const auto yStart = 0.0; const auto yEnd = 1.0;

    // constant spacing
    const auto dx = (xEnd - xStart) / (numX - 1);
    const auto dy = (yEnd - yStart) / (numY - 1);

    // coordinate vectors
    auto Nx = numX + 2 * numGP;
    auto vectorStartX = xStart - numGP * dx;
    auto vectorEndX = xEnd + numGP * dx;
    Eigen::VectorXd x1D = Eigen::VectorXd::LinSpaced(Nx, vectorStartX, vectorEndX);

    auto Ny = numY + 2 * numGP;
    auto vectorStartY = yStart - numGP * dy;
    auto vectorEndY = yEnd + numGP * dy;
    Eigen::VectorXd y1D = Eigen::VectorXd::LinSpaced(Ny, vectorStartY, vectorEndY);

    // create 2d grid as matrix
    Eigen::MatrixXd x = x1D.replicate(1, Ny);
    Eigen::MatrixXd y = y1D.transpose().replicate(Nx, 1);

    // check x and y
    std::cout << "x:\n" << x << std::endl;
    std::cout << "\ny:\n" << y << std::endl;

    // create non-copy view into grid without ghost cells
    auto xNoGP = x.block(numGP, numGP, Nx - 2 * numGP, Ny - 2 * numGP);
    auto yNoGP = y.block(numGP, numGP, Nx - 2 * numGP, Ny - 2 * numGP);

    // check x and y
    std::cout << "\nxNoGP:\n" << xNoGP << std::endl;
    std::cout << "\nyNoGP:\n" << yNoGP << std::endl;

    // create non-copy view into internal mesh only
    auto xInt = x.block(numGP + 1, numGP + 1, Nx - 2 * numGP - 2, Ny - 2 * numGP - 2);
    auto yInt = y.block(numGP + 1, numGP + 1, Nx - 2 * numGP - 2, Ny - 2 * numGP - 2);

    // check x and y
    std::cout << "\nxInt:\n" << xInt << std::endl;
    std::cout << "\nyInt:\n" << yInt << std::endl;

    // create non-copy view into east and west boundary
    auto xEast = x.block(numGP + numX - 1, numGP, 1, Ny - 2 * numGP);
    auto yEast = y.block(numGP + numX - 1, numGP, 1, Ny - 2 * numGP);
    auto xWest = x.block(numGP, numGP, 1, Ny - 2 * numGP);
    auto yWest = y.block(numGP, numGP, 1, Ny - 2 * numGP);

    // check x and y
    std::cout << "\nxEast:\n" << xEast << std::endl;
    std::cout << "yEast:\n" << yEast << std::endl;
    std::cout << "xWest:\n" << xWest << std::endl;
    std::cout << "yWest:\n" << yWest << std::endl;

    // create solution vector to store a variable on the mesh
    Eigen::MatrixXd phi = Eigen::MatrixXd::Random(Nx, Ny);

    // create views into phi data at boundaries
    Eigen::Block<Eigen::MatrixXd> phiNorthBC = phi.block(numGP, Ny - numGP - 1, numX, 1);
    Eigen::Block<Eigen::MatrixXd> phiSouthBC = phi.block(numGP, numGP, numX, 1);
    Eigen::Block<Eigen::MatrixXd> phiEastBC = phi.block(Nx - numGP - 1, numGP, 1, numY);
    Eigen::Block<Eigen::MatrixXd> phiWestBC = phi.block(numGP, numGP, 1, numY);

    // set boundary conditions, phi=1 at north boudnary, everything else to 0
    phiNorthBC.setConstant(1.0);
    phiSouthBC.setZero();
    phiEastBC.setZero();
    phiWestBC.setZero();

    // print out phi
    std::cout << "\nphi:\n" << phi << std::endl;

    // using blocks to compute the laplacian of phi
    auto i = numGP + 1;
    auto j = numGP + 1;
    auto sizeX = Nx - 2 * numGP - 2;
    auto sizeY = Ny - 2 * numGP - 2;
    auto dx2 = dx * dx;
    auto dy2 = dy * dy;

    Eigen::MatrixXd laplacian =
          phi.block(i + 1, j, sizeX, sizeY) / dx2
        - 2.0 * phi.block(i, j, sizeX, sizeY) / dx2
        + phi.block(i - 1, j, sizeX, sizeY) / dx2

        + phi.block(i, j + 1, sizeX, sizeY) / dy2
        - 2.0 * phi.block(i, j, sizeX, sizeY) / dy2
        + phi.block(i, j - 1, sizeX, sizeY) / dy2;

    // print out laplacian
    std::cout << "\nLaplacian:\n" << laplacian << std::endl;

    return 0;
}