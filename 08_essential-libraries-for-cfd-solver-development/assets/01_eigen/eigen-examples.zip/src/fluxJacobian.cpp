#include <iostream>
#include <Eigen/Dense>
#include <unsupported/Eigen/AutoDiff>

// compile-time constants
constexpr int NVAR = 3;   // rho, rho*u, E
constexpr double GAMMA = 1.4;

// AutoDiff scalar type
using ADScalar = typename Eigen::AutoDiffScalar<Eigen::VectorXd>;

// Vector types
using ADVector = typename Eigen::Matrix<ADScalar, NVAR, 1>;
using Vector   = typename Eigen::VectorXd;
using Matrix   = typename Eigen::MatrixXd;

// compute inviscid fluxes for Euler equation
template <typename Scalar>
Eigen::Matrix<Scalar, NVAR, 1> eulerFlux(const Eigen::Matrix<Scalar, NVAR, 1>& U)
{
    Scalar rho  = U(0);
    Scalar rhou = U(1);
    Scalar E    = U(2);

    Scalar u = rhou / rho;
    Scalar p = (GAMMA - 1.0) * (E - 0.5 * rho * u * u);

    Eigen::Matrix<Scalar, NVAR, 1> flux;
    flux(0) = rhou;
    flux(1) = rhou * u + p;
    flux(2) = u * (E + p);

    return flux;
}

int main()
{
    // primitive variables
    Vector U(NVAR);
    U << 1.0,   // rho
         1.0,   // rho*u
         2.5;   // E

    // create an auto-diff vector holding the same values as U
    ADVector U_ad;

    for (int i = 0; i < NVAR; ++i)
    {
        U_ad(i).value() = U(i);
        U_ad(i).derivatives() = Vector::Unit(NVAR, i);
    }

    // compute fluxes with auto-diff variables
    ADVector F_ad = eulerFlux(U_ad);

    // compute the flux jacobian, that is, dF/dU
    Matrix Jacobian_ad(NVAR, NVAR);

    for (int i = 0; i < NVAR; ++i)
        Jacobian_ad.row(i) = F_ad(i).derivatives().transpose();

    // compute flux jacobian from symbolic expression
    Matrix Jacobian(NVAR, NVAR);
    Matrix(0, 0) = 0.0;

    // print to screen
    std::cout << "State U:\n" << U.transpose() << "\n\n";
    std::cout << "Flux Jacobian dF/dU:\n" << Jacobian_ad << std::endl;

    return 0;
}