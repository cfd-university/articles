#include <iostream>
#include <Eigen/Dense>
#include <unsupported/Eigen/AutoDiff>

// compile-time constants
constexpr int NVAR = 3;   // rho, rho*u, E
constexpr double GAMMA = 1.4;

// AutoDiff scalar type
using ADScalar = typename Eigen::AutoDiffScalar<Eigen::VectorXd>;

// Vector types
using ADVector = typename Eigen::Matrix<ADScalar, NVAR, 1>;
using Vector   = typename Eigen::VectorXd;
using Matrix   = typename Eigen::MatrixXd;

// compute inviscid fluxes for Euler equation
ADVector eulerFlux(const ADVector& U)
{
    ADScalar rho  = U(0);
    ADScalar rhou = U(1);
    ADScalar E    = U(2);

    ADScalar u = rhou / rho;
    ADScalar p = (GAMMA - 1.0) * (E - 0.5 * rho * u * u);

    ADVector flux;
    flux(0) = rhou;
    flux(1) = rhou * u + p;
    flux(2) = u * (E + p);

    return flux;
}

int main()
{

    // primitive variables u (velocity), rho (density), E (energy), p (pressure), and H (enthalpy)
    double u = 1.0;
    double rho = 1.0;
    double E = 2.5;
    double p = (GAMMA - 1.0) * (E -0.5 * rho * u * u);
    double H = (E + p) / rho;

    // store primitive variables as a vector U
    Vector U(NVAR);
    U << rho, rho * u, E;

    // create an auto-diff vector holding the same values as U + derivatives
    ADVector U_ad;

    // set the values of U_ad to the same values as U, initialise the derivatives
    for (int i = 0; i < NVAR; ++i)
    {
        U_ad(i).value() = U(i);
        U_ad(i).derivatives() = Vector::Unit(NVAR, i);
    }

    // compute fluxes with auto-diff variables, now F_ad knows how it changes with respect to U
    // We can use that to get the derivative of F with respect to U, i.e. dF/dU
    ADVector F_ad = eulerFlux(U_ad);

    // compute the flux jacobian, that is, dF/dU
    Matrix Jacobian_ad(NVAR, NVAR);

    // compute each row separately. Since Eigen uses column vectors by default,
    // we need to transpose each vector to fill by rows
    for (int i = 0; i < NVAR; ++i)
        Jacobian_ad.row(i) = F_ad(i).derivatives().transpose();

    // compute flux jacobian from symbolic expression (for comparison)
    Matrix Jacobian(NVAR, NVAR);
    Jacobian(0,0) = 0.0;
    Jacobian(0,1) = 1.0;
    Jacobian(0,2) = 0.0;

    Jacobian(1,0) = (GAMMA - 3) / 2 * u;
    Jacobian(1,1) = (3.0 - GAMMA)*u;
    Jacobian(1,2) = GAMMA - 1.0;

    Jacobian(2,0) = u * ((GAMMA - 1.0) / 2.0 * u * u - H);
    Jacobian(2,1) = H - (GAMMA - 1) * u * u;
    Jacobian(2,2) = GAMMA * u;

    // print to screen
    std::cout << "State U:\n" << U.transpose() << "\n\n";
    std::cout << "Automatic differentiation Flux Jacobian dF/dU:\n" << Jacobian_ad << std::endl;
    std::cout << "\nSymbolic Flux Jacobian dF/dU:\n" << Jacobian << std::endl;
    std::cout << "\nDifference between auto-diff and symbolic evaluation:\n" << Jacobian - Jacobian_ad << std::endl;

    return 0;
}