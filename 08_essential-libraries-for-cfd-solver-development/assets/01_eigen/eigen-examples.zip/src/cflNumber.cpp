#include <iostream>
#include <Eigen/Eigen>

#define PI 3.141592

int main() {
    // number of cells and vertices
    const int nCells = 100;
    const int nVertices = nCells + 1;

    // some random velocity field
    auto u = Eigen::Vector<double, nCells>::Random();

    // create the mesh
    Eigen::VectorXd x = Eigen::VectorXd::LinSpaced(nVertices, 0, 1);

    // apply cosine clustering so that more points are towards either end
    x = 0.5 * (1.0 - (PI * x.array()).cos());

    // mesh spacing
    auto dx = x.tail(nVertices - 1) - x.head(nVertices - 1);

    // some assumed time step
    auto dt = 0.001;

    // compute the CFL number using the smallest spacing and largest velocity
    // CFL = max(u * dt / dx)
    auto CFL = (dt * u.array().abs() / dx.array()).maxCoeff();

    // print out some values
    std::cout << "CFL number:             " << CFL << std::endl;
    std::cout << "max velocity component: " << u.array().maxCoeff() << std::endl;
    std::cout << "minimum spacing dx:     " << dx.array().minCoeff() << std::endl;

    return 0;
}