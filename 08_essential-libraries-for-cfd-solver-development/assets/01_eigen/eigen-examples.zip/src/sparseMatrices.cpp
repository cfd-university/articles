#include <iostream>
#include <Eigen/Eigen>

int main() {
    // create a 3 by 3 matrix, with size set at runtime
    Eigen::SparseMatrix<double> mat1(3, 3);

    // insert values, for example, make it an identity matrix
    mat1.insert(0, 0) = 1;
    mat1.insert(1, 1) = 1;
    mat1.insert(2, 2) = 1;

    // optimsie storage for performance (optional, but recommended)
    mat1.makeCompressed();

    // create a sparse vector of size 3
    Eigen::SparseVector<double> vec1(3);

    // set values in vector
    vec1.insert(0) = 1;
    vec1.insert(1) = 2;
    vec1.insert(2) = 3;

    // we can still apply normal matrix-vector arithmetic
    auto vec2 = mat1 * vec1;

    // we can also still aply reduction operations
    auto traceManual = mat1.diagonal().sum();

    // printing matrices and vectors
    std::cout << "sparse matrix 1:\n" << mat1 << std::endl;
    std::cout << "sparse vector 1:\n" << vec1 << std::endl;
    std::cout << "sparse vector 2:\n" << vec2 << std::endl;
    std::cout << "trace(mat1): " << traceManual << std::endl;

    // vector 1 shows internal state. To cast to normal vector, print the following way:
    std::cout << "vector 1:\n" << Eigen::VectorXd(vec1) << std::endl;

    return 0;
}