#include <iostream>
#include <Eigen/Eigen>

int main() {
    // use a typedef to define a 3 by 3 matrix, fixed at compile time
    Eigen::Matrix3d mat1;

    // create a compile-time fixed vector of size 3
    Eigen::Matrix<double, 3, 1> vec1;

    // create a run-time fixed vector of size 3
    Eigen::Matrix<double, Eigen::Dynamic, 1> vec2(3);

    // we can again resize the vector if we want
    vec2.resize(3);

    // set matrix and vector to random values
    mat1.setRandom();
    vec1.setRandom();
    vec2 = vec1;

    // compute the matrix vector product
    auto vec3 = mat1 * vec1;
    auto vec4 = mat1 * vec2;

    // compute the vector matrix product, using the transpose
    auto vec5 = vec1.transpose() * mat1;
    auto vec6 = vec2.transpose() * mat1;

    // scalar (dot) product of vec5 and vec6
    auto dot = vec5.dot(vec6);

    // compute the L2 norm of vector 3
    auto L2norm1 = vec3.norm();

    // compute the L2 norm of vector 3 with verbose syntax
    auto L2norm2 = vec3.lpNorm<2>();

    // compute the L1 norm of vector 3
    auto L1norm = vec3.lpNorm<1>();

    // compute the infinity norm of vector 3
    auto infnorm = vec3.lpNorm<Eigen::Infinity>();

    // print results
    std::cout << "matrix 1:\n" << mat1 << std::endl;
    std::cout << "vector 1:\n" << vec1 << std::endl;
    std::cout << "vector 2:\n" << vec2 << std::endl;
    std::cout << "vector 3:\n" << vec3 << std::endl;
    std::cout << "vector 4:\n" << vec4 << std::endl;
    std::cout << "vector 5:\n" << vec5 << std::endl;
    std::cout << "vector 6:\n" << vec6 << std::endl;
    std::cout << "dot product of vector 5 and vector 6:\n" << dot << std::endl;
    std::cout << "L2 norm of vector 3:\n" << L2norm1 << std::endl;
    std::cout << "L2 norm of vector 3:\n" << L2norm2 << std::endl;
    std::cout << "L1 norm of vector 3:\n" << L1norm << std::endl;
    std::cout << "infinity norm of vector 3:\n" << infnorm << std::endl;

    return 0;
}