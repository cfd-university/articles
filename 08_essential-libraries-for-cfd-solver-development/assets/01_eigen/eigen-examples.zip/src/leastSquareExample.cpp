#include <iostream>
#include <Eigen/Eigen>

class Gradient {
public:
    using VectorType = typename Eigen::Matrix<double, Eigen::Dynamic, 1>;
    using MatrixType = typename Eigen::Matrix<double, Eigen::Dynamic, 2>;

public:
    Gradient(const VectorType &dx, const VectorType &dy) {
        _A.resize(dx.rows(), 2);
        _A.col(0) = dx;
        _A.col(1) = dy;
    }

    // Least-squares method
    VectorType leastSquares(const VectorType &phiDifferences) const {
        MatrixType ATA = _A.transpose() * _A;
        VectorType ATb = _A.transpose() * phiDifferences;
        return ATA.inverse() * ATb;
    }
    
    // Cholesky decomposition
    VectorType cholesky(const VectorType &phiDifferences) const {
        MatrixType ATA = _A.transpose() * _A;
        VectorType ATb = _A.transpose() * phiDifferences;
        return ATA.ldlt().solve(ATb);
    }

    // LU decomposition
    VectorType lu(const VectorType &phiDifferences) const {
        MatrixType ATA = _A.transpose() * _A;
        VectorType ATb = _A.transpose() * phiDifferences;
        return ATA.partialPivLu().solve(ATb);
    }

    // QR decomposition
    VectorType qr(const VectorType &phiDifferences) const {
        return _A.colPivHouseholderQr().solve(phiDifferences);
    }

    // Single-value decomposition reconstruction
    VectorType svd(const VectorType &phiDifferences) const {
        return _A.bdcSvd(Eigen::ComputeThinU | Eigen::ComputeThinV).solve(phiDifferences);
    }

private:
    MatrixType _A;
};

int main() {
    // difference between phi at the cell centroid and its neighbours
    Gradient::VectorType phi(4);
    phi << 5.3 - 1.6, 1.96 - 1.6, -0.11 - 1.6, 0.86 - 1.6;

    // delta x vector
    Gradient::VectorType dx(4);
    dx << 1.375, 0.0, -1.375, 0.0;

    // delta y vector
    Gradient::VectorType dy(4);
    dy << 0.0, -1.375, -0.25, 1.375;

    // compute least squares gradient
    Gradient grad(dx, dy);

    std::cout << "Least squares gradient: (" << grad.leastSquares(phi).transpose() << ")" << std::endl;
    std::cout << "LU       decomposition: (" << grad.lu(phi).transpose() << ")" << std::endl;
    std::cout << "Cholesky decomposition: (" << grad.cholesky(phi).transpose() << ")" << std::endl;
    std::cout << "QR       decomposition: (" << grad.qr(phi).transpose() << ")" << std::endl;
    std::cout << "SVD      decomposition: (" << grad.svd(phi).transpose() << ")" << std::endl;

    return 0;
}