#include <iostream>
#include <Eigen/Eigen>

class Triangle {
public:
    using PointType = typename Eigen::Vector3d;

public:
    Triangle(PointType p1, PointType p2, PointType p3) : _p1(p1), _p2(p2), _p3(p3) {
        calculateNormalVector();
        calculateArea();
    }

    ~Triangle() {}

    double getArea() { return _area; }
    PointType getNormalVector() { return _normalVector; }

private:
    void calculateNormalVector() {
        auto tempNormalVector = normalVector();
        tempNormalVector.normalize();
        _normalVector = tempNormalVector;
    }

    void calculateArea() {
        auto tempNormalVector = normalVector();
        _area = tempNormalVector.norm() / 2;    
    }

    PointType normalVector() {
        auto p2p1 = _p2 - _p1;
        auto p3p1 = _p3 - _p1;
        auto normalVector = p2p1.cross(p3p1);
        return normalVector;
    }

private:
    PointType _p1;
    PointType _p2;
    PointType _p3;
    double _area;
    PointType _normalVector;
};

int main() {
    // create 3 points in the xy plane
    Eigen::Vector3d p1 = {0, 0, 0};
    Eigen::Vector3d p2 = {1, 0, 0};
    Eigen::Vector3d p3 = {0, 1, 0};

    Triangle triangle(p1, p2, p3);
    std::cout << "Area of triangle: " << triangle.getArea() << std::endl;
    std::cout << "Normal vector of triangle: (" << triangle.getNormalVector().transpose() << ")" << std::endl;

    return 0;
}