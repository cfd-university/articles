#include <iostream>
#include <cassert>

#include <Eigen/Eigen>

// solve the heat equation implicitly of the form dT/dt = gamma * d^2 T/ dx^2
// over a domain L using the conjugate gradient methdod
// initial condition: 0 everywhere
// boundary condition: T(0) = 0, T(L) = 1
int main() {
  // input variables
  const double gamma = 1.0;
  const unsigned numberOfCells = 100;
  const double domainLength = 1.0;
  const double boundaryValueLeft = 0.0;
  const double boundaryValueRight = 1.0;
  const double dx = domainLength / (numberOfCells);

  // vectors and matrices
  Eigen::SparseVector<double> coordinateX(numberOfCells);
  Eigen::SparseVector<double> temperature(numberOfCells);
  Eigen::SparseVector<double> boundaryConditions(numberOfCells);

  Eigen::SparseMatrix<double> coefficientMatrix(numberOfCells, numberOfCells);

  // initialise arrays and set-up 1D mesh
  for (unsigned i = 0; i < numberOfCells; ++i) {
    coordinateX.insert(i) = i * dx + dx / 2.0;
    temperature.insert(i) = 0.0;
    boundaryConditions.insert(i) = 0.0;
  }

  // calculate individual matrix coefficients
  const double aE = gamma / dx;
  const double aW = gamma / dx;
  const double aP = -2.0 * gamma / dx;

  // set individual matrix coefficients
  for (unsigned i = 1; i < numberOfCells - 1; ++i) {
    coefficientMatrix.insert(i, i) = aP;
    coefficientMatrix.insert(i, i + 1) = aE;
    coefficientMatrix.insert(i, i - 1) = aW;
  }

  coefficientMatrix.insert(0, 0) = -3.0 * gamma / dx;
  coefficientMatrix.insert(0, 1) = aE;
  coefficientMatrix.insert(numberOfCells - 1, numberOfCells - 2) = aW;
  coefficientMatrix.insert(numberOfCells - 1, numberOfCells - 1) = -3.0 * gamma / dx;

  // set boundary conditions
  boundaryConditions.coeffRef(0) = -2.0 * aW * boundaryValueLeft;
  boundaryConditions.coeffRef(numberOfCells - 1) = -2.0 * aE * boundaryValueRight;

  // solve the linear system using the conjugate gradient method
  Eigen::ConjugateGradient<Eigen::SparseMatrix<double>, Eigen::Lower | Eigen::Upper> CGSolver;
  CGSolver.compute(coefficientMatrix);
  CGSolver.setTolerance(1e-10);
  CGSolver.setMaxIterations(1000);
  temperature = CGSolver.solve(boundaryConditions);
  auto getIterations = CGSolver.iterations();

  // the obtain temperature profile is a linear one of the form T(x) = x. Thus, we can compare it directly against
  // the coordinate vector (which in this case acts as an analytic solution)
  auto difference = temperature - coordinateX;
  auto L2norm = difference.norm();

  // ensure that temperature has converged to at least single precision
  assert(L2norm < 1e-8);

  std::cout << "Simulation successful in " << getIterations << " iterations, final residual: " << L2norm << std::endl;
  return 0;
}