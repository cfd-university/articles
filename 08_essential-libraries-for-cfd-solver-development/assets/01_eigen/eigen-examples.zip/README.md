## Installing prerequisits

To run the example code, you will need to have installed the following:

- A C++ compiler (e.g. [MSVS](https://visualstudio.microsoft.com/vs/community/), [g++](https://gcc.gnu.org/), [clang++](https://clang.llvm.org/))
- CMake

You have two options to get your prerequisits installed:

- Automatically using Python's package manager (recommended)
- Manual

For the manual installation route, follow the links provided above and install any missing dependencies. For the automatic route, ensure you have [Python](https://www.python.org/downloads/) installed. This is the only dependency. Then, install all required dependencies with:

```bash
pip install -r .\requirements.txt
```

On some, operating systems, you may not be able to install dependencies globally, and you will get the following error message:

```bash
error: externally-managed-environment
× This environment is externally managed
```

In this case, install all dependencies into a virtual environment. First, you will have to create a virtual environment using:

UNIX:
```bash
python3 -m venv .venv
source .venv/bin/activate
```

Windows:
```bash
py -m venv .venv
.\.venv\Scripts\Activate.ps1
```

Now you can run ```pip install -r .\requirements.txt``` again and install all dependencies. If you are new to virtual environments, make sure to [read this primer](https://realpython.com/python-virtual-environments-a-primer/) to understand how they work. 

## Installing project dependencies

You should have a development environment set up now so that you can compile and run all code examples. We use [conan](https://conan.io/), one of the best package managers fr C++, to install all required dependencies. If this is the first tme you are using Conan, you'll need to create a profile first. Start by creating a default profile first using: 

```bash
conan profile detect --force
```

This will store information about your environment, compiler, operating system, and so on. You can create different profiles for installing dependencies for development (e.g. with debug information) and for release (optimisation turned on). Look at the [profile documentation](https://docs.conan.io/2/reference/config_files/profiles.html) if you want to find out more.

Next, execute Conan to install all required external libraries using:

```bash
conan install . --build=missing --settings=build_type=Release
```

This will download binaries, where available, or source code which is then compiled (as necessary). Information on how ```CMake``` can find these dependencies are placed in the ```build/``` folder. Based on your build system used by ```CMake```, this may be located in one of the following two locations/files:

- ```build/Release/generators/conan_toolchain.cmake```
- ```build/generators/conan_toolchain.cmake```

Take note where yours is located, the rest of the instructions will assume the first location but replace that, if needed, by the second location if this is where ```conan``` stored information for you.

## Compiling the project

We are now ready to configure and compile our project using ```CMake```.

First, we configure the project using the following command:

```bash
cmake -B build/ -S . -DCMAKE_BUILD_TYPE=Release -DCMAKE_TOOLCHAIN_FILE='build/Release/generators/conan_toolchain.cmake'
```

With the project configured, we can now compile it using the following command:

```bash
cmake --build build/ --config Release
```

## Running the executables

Your executable should now be created and either located on ```build/app.exe``` or ```build/Debug/app.exe```. Replace the name ```app.exe``` with the actual name of the executable. The exact location will depend on your operating system and build system. 