#include <iostream>
#include <vector>
#include <toml.hpp>

int main()
{
    const auto config = toml::parse("config.toml");

    // meshing node
    const auto numPointsX = toml::find<int>(config, "meshing", "numPointsX");
    const auto numPointsY = toml::find<int>(config, "meshing", "numPointsY");

    // boundaryConditions node
    const auto north = toml::find<std::string>(config, "boundaryConditions", "north");
    const auto south = toml::find<std::string>(config, "boundaryConditions", "south");
    const auto east  = toml::find<std::string>(config, "boundaryConditions", "east");
    const auto west  = toml::find<std::string>(config, "boundaryConditions", "west");

    // solver node
    const auto turbulence = toml::find<bool>(config, "solver", "turbulence");
    const auto model = toml::find<std::string>(config, "solver", "model");
    const auto CFL = toml::find<std::vector<double>>(config, "solver", "CFL");

    // output (sanity check)
    std::cout << "numPointsX = " << numPointsX << std::endl;
    std::cout << "numPointsY = " << numPointsY << std::endl;

    std::cout << "north = " << north << std::endl;
    std::cout << "south = " << south << std::endl;
    std::cout << "east  = " << east  << std::endl;
    std::cout << "west  = " << west  << std::endl;

    std::cout << "turbulence = " << std::boolalpha << turbulence << std::endl;
    std::cout << "model = " << model << std::endl;

    std::cout << "CFL = ";
    for(const auto c : CFL)
        std::cout << c << ' ';
    std::cout << std::endl;

    return 0;
}