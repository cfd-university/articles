#include <pugixml.hpp>

int main()
{
    pugi::xml_document doc;

    // XML declaration
    pugi::xml_node header = doc.prepend_child(pugi::node_declaration);
    header.append_attribute("version") = "1.0";
    header.append_attribute("encoding") = "UTF-8";

    // Root element
    pugi::xml_node root = doc.append_child("configuration");

    // meshing
    pugi::xml_node meshing = root.append_child("meshing");

    meshing.append_child("numPointsX").text() = 128;
    meshing.append_child("numPointsY").text() = 128;

    // boundaryConditions
    pugi::xml_node bc = root.append_child("boundaryConditions");

    bc.append_child("north").text() = "Dirichlet";
    bc.append_child("south").text() = "Neumann";
    bc.append_child("east").text()  = "Neumann";
    bc.append_child("west").text()  = "Dirichlet";

    // solver
    pugi::xml_node solver = root.append_child("solver");

    solver.append_child("turbulence").text() = true;
    solver.append_child("model").text() = "komega-SST";

    pugi::xml_node cfl = solver.append_child("CFL");
    cfl.append_child("Item1").text() = 0.000001;
    cfl.append_child("Item2").text() = 1.0;
    cfl.append_child("Item3").text() = 10.0;

    // Save pretty-printed XML
    doc.save_file("config.xml");

    return 0;
}