#include <fstream>
#include <iostream>
#include <nlohmann/json.hpp>

int main() {
    nlohmann::json config;

    config["meshing"]["numPointsX"] = 128;
    config["meshing"]["numPointsY"] = 128;

    config["boundaryConditions"]["north"] = "Dirichlet";
    config["boundaryConditions"]["south"] = "Neumann";
    config["boundaryConditions"]["east"]  = "Neumann";
    config["boundaryConditions"]["west"]  = "Dirichlet";

    config["solver"]["turbulence"] = true;
    config["solver"]["model"] = "komega-SST";
    config["solver"]["CFL"] = { 1e-6, 1, 10 };

    std::ofstream outFile("config.json");

    outFile << config.dump(4);
    outFile.close();

    return 0;
}