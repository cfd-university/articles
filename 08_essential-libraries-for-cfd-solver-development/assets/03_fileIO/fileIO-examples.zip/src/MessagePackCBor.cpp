#include <cstdint>
#include <fstream>
#include <iostream>
#include <stdexcept>
#include <string>
#include <vector>

#include <nlohmann/json.hpp>

int main()
{   
    // read the config file generated in the JSON section
    std::ifstream inFile("config.json");
    nlohmann::json config;
    inFile >> config;

    // convert the json object to cbor and messagepack
    auto cborData = nlohmann::json::to_cbor(config);
    auto msgpackData = nlohmann::json::to_msgpack(config);

    // write cbor and messagepack created objects to disk as a binary file
    std::ofstream cborWrite("config.cbor", std::ios::binary);
    cborWrite.write(reinterpret_cast<const char*>(cborData.data()), cborData.size());
    cborWrite.close();
        
    std::ofstream msgpackWrite("config.msgpack", std::ios::binary);
    msgpackWrite.write(reinterpret_cast<const char*>(msgpackData.data()), msgpackData.size());
    msgpackWrite.close();

    // reading the same binary files back from disk now
    std::ifstream cborConfig("config.cbor", std::ios::binary);
    std::vector<uint8_t> cborRead((std::istreambuf_iterator<char>(cborConfig)), std::istreambuf_iterator<char>());

    std::ifstream msgpackConfig("config.msgpack", std::ios::binary);
    std::vector<uint8_t> msgpackRead((std::istreambuf_iterator<char>(msgpackConfig)), std::istreambuf_iterator<char>());

    // convert their content to json
    auto cbor2json = nlohmann::json::from_cbor(cborRead);
    auto msgpack2json = nlohmann::json::from_msgpack(msgpackRead);

    // sanity check, did we get the same number of points back after serialisation? 
    std::cout << "Property   | JSON | CBOR | MessagePack" << std::endl;
    std::cout << "numPointsX | " << config["meshing"]["numPointsX"] << "  | ";
    std::cout << cbor2json["meshing"]["numPointsX"] << "  | ";
    std::cout << msgpack2json["meshing"]["numPointsX"] << std::endl;

    return 0;
}