#include "excelnt.hpp"

int main() {

    excelnt::Table table;

    // meshing
    table["meshing.numPointsX"] = std::vector<int>{64, 128, 256};
    table["meshing.numPointsY"] = std::vector<int>{64, 128, 256};

    // boundaryConditions
    table["boundaryConditions.north"] = "Dirichlet";
    table["boundaryConditions.south"] = "Neumann";
    table["boundaryConditions.east"]  = "Neumann";
    table["boundaryConditions.west"]  = "Dirichlet";

    // solver
    table["solver.turbulence"] = true;
    table["solver.model"] = "komega-SST";
    table["solver.CFL.min_dt"] = "1e-6";
    table["solver.CFL.max_dt"] = "1.0";
    table["solver.CFL.CFL"] = "10.0";

    excelnt::write("config.csv", table);

    return 0;
}