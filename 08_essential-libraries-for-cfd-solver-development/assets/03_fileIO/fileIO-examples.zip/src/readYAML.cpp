#include <ryml.hpp>
#include <ryml_std.hpp>
#include <c4/yml/file.hpp>

#include <fstream>
#include <iostream>
#include <iterator>
#include <string>
#include <vector>

int main() {
    // Read entire file
    // std::ifstream in("config.yaml");
    // std::string contents(
    //     (std::istreambuf_iterator<char>(in)),
    //     std::istreambuf_iterator<char>());

    // // rapidyaml parses in-place, so use a mutable buffer
    // std::vector<char> buffer(contents.begin(), contents.end());

    // c4::yml::Tree tree = c4::yml::parse_in_place(
    //     ryml::to_substr(buffer));
    std::string contents = c4::yml::file_get_contents<std::string>("config.yaml");
    ryml::Tree tree = ryml::parse_in_arena(ryml::to_csubstr(contents));
    auto root = tree.rootref();

    // meshing
    int numPointsX, numPointsY;
    root["meshing"]["numPointsX"] >> numPointsX;
    root["meshing"]["numPointsY"] >> numPointsY;

    // boundary conditions
    std::string north, south, east, west;
    root["boundaryConditions"]["north"] >> north;
    root["boundaryConditions"]["south"] >> south;
    root["boundaryConditions"]["east"]  >> east;
    root["boundaryConditions"]["west"]  >> west;

    // solver
    bool turbulence;
    root["solver"]["turbulence"] >> turbulence;
    
    std::string model;
    root["solver"]["model"] >> model;

    auto cfl = root["solver"]["CFL"];
    double cfl0, cfl1, cfl2;
    cfl[0] >> cfl0;
    cfl[1] >> cfl1;
    cfl[2] >> cfl2;

    std::cout << "numPointsX = " << numPointsX << '\n';
    std::cout << "numPointsY = " << numPointsY << '\n';

    std::cout << "north = " << north << '\n';
    std::cout << "south = " << south << '\n';
    std::cout << "east  = " << east  << '\n';
    std::cout << "west  = " << west  << '\n';

    std::cout << "turbulence = "
              << std::boolalpha << turbulence << '\n';

    std::cout << "model = " << model << '\n';

    std::cout << "CFL = ["
              << cfl0 << ", "
              << cfl1 << ", "
              << cfl2 << "]\n";

    return 0;
}