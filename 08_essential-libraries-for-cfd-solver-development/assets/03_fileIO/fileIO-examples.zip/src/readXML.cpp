#include <iostream>
#include <vector>
#include <pugixml.hpp>

int main()
{
    // read XML file
    pugi::xml_document doc;
    pugi::xml_parse_result result = doc.load_file("config.xml");

    pugi::xml_node root = doc.child("configuration");

    // meshing
    pugi::xml_node meshing = root.child("meshing");

    int nx = meshing.child("numPointsX").text().as_int();
    int ny = meshing.child("numPointsY").text().as_int();

    // boundary conditions
    pugi::xml_node bc = root.child("boundaryConditions");

    std::string north = bc.child("north").text().as_string();
    std::string south = bc.child("south").text().as_string();
    std::string east  = bc.child("east").text().as_string();
    std::string west  = bc.child("west").text().as_string();

    // solver
    pugi::xml_node solver = root.child("solver");
    bool turbulence = solver.child("turbulence").text().as_bool();
    std::string model = solver.child("model").text().as_string();

    std::vector<double> cfl;
    pugi::xml_node cflNode = solver.child("CFL");
    cfl.push_back(cflNode.child("Item1").text().as_double());
    cfl.push_back(cflNode.child("Item2").text().as_double());
    cfl.push_back(cflNode.child("Item3").text().as_double());

    std::cout << "cfl[0]: " << cfl[0] << std::endl;
    std::cout << "cfl[1]: " << cfl[1] << std::endl;
    std::cout << "cfl[2]: " << cfl[2] << std::endl;

    return 0;
}