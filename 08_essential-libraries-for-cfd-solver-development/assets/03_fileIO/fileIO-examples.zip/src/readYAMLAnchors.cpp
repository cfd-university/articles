#include <ryml.hpp>
#include <ryml_std.hpp>
#include <c4/yml/file.hpp>

#include <fstream>
#include <iostream>
#include <iterator>
#include <string>
#include <vector>

int main() {
    std::string contents = c4::yml::file_get_contents<std::string>("configWithAnchors.yaml");
    ryml::Tree tree = ryml::parse_in_arena(ryml::to_csubstr(contents));
    auto root = tree.rootref();

    // loop over all cases
    for (const char *currentCase : {"coarse", "medium", "fine"}) {
        
        // meshing
        int numPointsX, numPointsY;
        root["cases"][currentCase]["meshing"]["numPointsX"] >> numPointsX;
        root["cases"][currentCase]["meshing"]["numPointsY"] >> numPointsY;

        std::cout << "currentCase = " << currentCase << std::endl;
        std::cout << "numPointsX  = " << numPointsX << std::endl;
        std::cout << "numPointsY  = " << numPointsY << std::endl;
        std::cout << std::endl;
    
    }

    return 0;
}