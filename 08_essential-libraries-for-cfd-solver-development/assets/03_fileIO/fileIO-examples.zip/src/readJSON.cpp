#include <fstream>
#include <iostream>
#include <nlohmann/json.hpp>

int main() {
    std::ifstream inFile("config.json");
    nlohmann::json config;
    inFile >> config;

    int numPointsX = config["meshing"]["numPointsX"].get<int>();
    int numPointsY = config["meshing"]["numPointsY"].get<int>();

    std::string north = config["boundaryConditions"]["north"].get<std::string>();
    std::string south = config["boundaryConditions"]["south"].get<std::string>();
    std::string east  = config["boundaryConditions"]["east"].get<std::string>();
    std::string west  = config["boundaryConditions"]["west"].get<std::string>();

    bool turbulence = config["solver"]["turbulence"].get<bool>();
    std::string model = config["solver"]["model"].get<std::string>();
    std::vector<double> cfl = config["solver"]["CFL"].get<std::vector<double>>();

    return 0;
}