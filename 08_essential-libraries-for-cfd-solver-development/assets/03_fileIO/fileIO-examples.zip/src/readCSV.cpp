#include <iostream>

#include "excelnt.hpp"

int main() {

    const auto table = excelnt::read("config.csv");

    // meshing
    const auto numPointsX = table["meshing.numPointsX"].asInt();
    const auto numPointsY = table["meshing.numPointsY"].asInt();

    // boundary conditions
    const auto north = table["boundaryConditions.north"].asString();
    const auto south = table["boundaryConditions.south"].asString();
    const auto east  = table["boundaryConditions.east"].asString();
    const auto west  = table["boundaryConditions.west"].asString();

    // solver
    const auto turbulence = table["solver.turbulence"].asBool();
    const auto model = table["solver.model"].asString();
    const auto minDt = table["solver.CFL.min_dt"].asDouble();
    const auto maxDt = table["solver.CFL.max_dt"].asDouble();
    const auto CFL = table["solver.CFL.CFL"].asDouble();

    // sanity check output (everything is read as a std::vector, so we print the first (and only) element)
    std::cout << "numPointsX = " << numPointsX[0] << std::endl;
    std::cout << "numPointsY = " << numPointsY[0] << std::endl;

    std::cout << "north = " << north[0] << std::endl;
    std::cout << "south = " << south[0] << std::endl;
    std::cout << "east  = " << east[0]  << std::endl;
    std::cout << "west  = " << west[0]  << std::endl;

    std::cout << "turbulence = " << std::boolalpha << turbulence[0] << std::endl;
    std::cout << "model = " << model[0] << std::endl;
    std::cout << "min_dt = " << minDt[0] << std::endl;
    std::cout << "max_dt = " << maxDt[0] << std::endl;
    std::cout << "CFL = " << CFL[0] << std::endl;

    return 0;
}