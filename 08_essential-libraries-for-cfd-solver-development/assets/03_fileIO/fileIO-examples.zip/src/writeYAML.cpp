#include <ryml.hpp>
#include <ryml_std.hpp>

#include <fstream>
#include <string>

int main() {
    c4::yml::Tree tree;
    auto root = tree.rootref();
    root |= c4::yml::MAP;

    // meshing
    auto meshing = root["meshing"];
    meshing |= c4::yml::MAP;
    meshing["numPointsX"] << 128;
    meshing["numPointsY"] << 128;

    // boundaryConditions
    auto bc = root["boundaryConditions"];
    bc |= c4::yml::MAP;
    bc["north"] << "Dirichlet";
    bc["south"] << "Neumann";
    bc["east"]  << "Neumann";
    bc["west"]  << "Dirichlet";

    // solver
    auto solver = root["solver"];
    solver |= c4::yml::MAP;

    solver["turbulence"] << true;
    solver["model"] << "komega-SST";

    auto cfl = solver["CFL"];
    cfl |= c4::yml::SEQ;
    cfl.append_child() << 1e-6;
    cfl.append_child() << 1.0;
    cfl.append_child() << 10.0;

    // Emit YAML to std::string
    std::string yaml = c4::yml::emitrs_yaml<std::string>(tree);

    std::ofstream out("config.yaml");
    out << yaml;

    return 0;
}