#include <fstream>
#include <toml.hpp>

int main()
{
    toml::value config;

    // [meshing]
    config["meshing"] = toml::table{
        {"numPointsX", 128},
        {"numPointsY", 128}
    };

    // [boundaryConditions]
    config["boundaryConditions"] = toml::table{
        {"north", "Dirichlet"},
        {"south", "Neumann"},
        {"east",  "Neumann"},
        {"west",  "Dirichlet"}
    };

    // [solver]
    config["solver"] = toml::table{
        {"turbulence", true},
        {"model", "komega-SST"},
        {"CFL", toml::array{1e-6, 1.0, 10.0}}
    };

    std::ofstream ofs("config.toml");
    ofs << toml::format(config);

    return 0;
}