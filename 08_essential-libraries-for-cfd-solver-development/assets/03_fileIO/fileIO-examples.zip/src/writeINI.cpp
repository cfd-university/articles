#include <iostream>
#include <sstream>
#include <vector>
#include <string>

#include "mini/ini.h"

int main()
{
    mINI::INIStructure config;

    // [meshing]
    config["meshing"]["numPointsX"] = "128";
    config["meshing"]["numPointsY"] = "128";

    // [boundaryConditions]
    config["boundaryConditions"]["north"] = "Dirichlet";
    config["boundaryConditions"]["south"] = "Neumann";
    config["boundaryConditions"]["east"]  = "Neumann";
    config["boundaryConditions"]["west"]  = "Dirichlet";

    // [solver]
    config["solver"]["turbulence"] = "true";
    config["solver"]["model"]      = "komega-SST";
    config["solver"]["CFL"]        = "1e-6,1,10";

    mINI::INIFile outFile("config.ini");
    outFile.generate(config);

    return 0;
}