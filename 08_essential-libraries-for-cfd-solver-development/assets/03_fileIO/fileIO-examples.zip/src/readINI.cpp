#include <iostream>
#include <sstream>
#include <vector>
#include <string>

#include "mini/ini.h"

int main()
{
    mINI::INIStructure config;
    mINI::INIFile inFile("config.ini");
    inFile.read(config);

    int numPointsX = std::stoi(config["meshing"]["numPointsX"]);
    int numPointsY = std::stoi(config["meshing"]["numPointsY"]);

    std::string north = config["boundaryConditions"]["north"];
    std::string south = config["boundaryConditions"]["south"];
    std::string east  = config["boundaryConditions"]["east"];
    std::string west  = config["boundaryConditions"]["west"];

    bool turbulence = config["solver"]["turbulence"] == "true";

    std::string model = config["solver"]["model"];

    // Parse CFL array
    std::vector<double> cfl;
    {
        std::stringstream ss(config["solver"]["CFL"]);
        std::string argument;

        while (std::getline(ss, argument, ','))
        {
            cfl.push_back(std::stod(argument));
        }
    }

    // Print values
    std::cout << "numPointsX = " << numPointsX << '\n';
    std::cout << "numPointsY = " << numPointsY << '\n';

    std::cout << "north = " << north << '\n';
    std::cout << "south = " << south << '\n';
    std::cout << "east  = " << east  << '\n';
    std::cout << "west  = " << west  << '\n';

    std::cout << "turbulence = " << std::boolalpha
              << turbulence << '\n';

    std::cout << "model = " << model << '\n';

    std::cout << "CFL = ";
    for (double v : cfl)
        std::cout << v << " ";
    std::cout << '\n';

    return 0;
}