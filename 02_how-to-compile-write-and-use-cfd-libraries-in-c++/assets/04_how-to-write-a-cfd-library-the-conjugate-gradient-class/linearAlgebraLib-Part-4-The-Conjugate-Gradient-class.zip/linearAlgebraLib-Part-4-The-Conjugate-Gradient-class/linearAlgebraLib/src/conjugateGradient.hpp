#pragma once

#include <iostream>

#include "linearAlgebraLib/src/linearAlgebraSolverBase.hpp"
#include "linearAlgebraLib/src/sparseMatrixCSR.hpp"
#include "linearAlgebraLib/src/vector.hpp"

namespace linearAlgebraLib {

class ConjugateGradient : public LinearAlgebraSolverBase {
public:
  ConjugateGradient(unsigned numberOfCells);
  virtual Vector solve(unsigned maxIterations, double convergenceThreshold) final override;
};

} // namespace linearAlgebraLib