#include "src/sparseMatrixCSR.hpp"
#include "src/vector.hpp"
#include "src/linearAlgebraSolverBase.hpp"
#include "src/conjugateGradient.hpp"
