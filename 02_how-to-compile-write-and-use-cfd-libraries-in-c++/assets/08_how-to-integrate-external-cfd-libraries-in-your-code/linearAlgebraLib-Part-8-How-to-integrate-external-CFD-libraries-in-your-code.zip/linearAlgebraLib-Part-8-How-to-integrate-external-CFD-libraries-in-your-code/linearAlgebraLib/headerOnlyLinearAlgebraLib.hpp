#include "headerOnly/sparseMatrixCSR.hpp"
#include "headerOnly/vector.hpp"
#include "headerOnly/linearAlgebraSolverBase.hpp"
#include "headerOnly/conjugateGradient.hpp"
