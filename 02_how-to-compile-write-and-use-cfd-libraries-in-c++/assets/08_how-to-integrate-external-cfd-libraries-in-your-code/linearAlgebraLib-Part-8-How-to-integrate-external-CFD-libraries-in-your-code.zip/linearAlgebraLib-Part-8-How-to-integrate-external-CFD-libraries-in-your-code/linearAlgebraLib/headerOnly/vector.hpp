#pragma once

#include <iostream>
#include <vector>
#include <cassert>
#include <cmath>

namespace linearAlgebraLib {

class Vector {
public:
  using VectorType = std::vector<double>;

public:
  Vector(const unsigned &size) {
    _vector.resize(size, 0.0);
  }

  unsigned size() const {
    return _vector.size();
  }

  Vector transpose() {
    Vector transposedVector(_vector.size());
    transposedVector._vector = _vector;
    transposedVector._isRowVector = _isRowVector == true ? false : true;
    return transposedVector;
  }

  double getL2Norm() const {
    double L2Norm = 0.0;
    for (const auto &entry : _vector)
      L2Norm += std::pow(entry, 2);
    L2Norm = std::sqrt(L2Norm);
    return L2Norm;
  }

  const double &operator[](unsigned index) const {
    return _vector[index];
  }

  double &operator[](unsigned index) {
    return _vector[index];
  }

  Vector operator+(const Vector &other) {
    assert(_vector.size() == other._vector.size() && "vectors must have the same dimension");
    Vector resultVector(_vector.size());
    resultVector._vector.resize(_vector.size());
    for (unsigned i = 0; i < _vector.size(); ++i)
      resultVector._vector[i] = _vector[i] + other._vector[i];
    return resultVector;
  }

  Vector operator-(const Vector &other) {
    assert(_vector.size() == other._vector.size() && "vectors must have the same dimension");
    Vector resultVector(_vector.size());
    resultVector._vector.resize(_vector.size());
    for (unsigned i = 0; i < _vector.size(); ++i)
      resultVector._vector[i] = _vector[i] - other._vector[i];
    return resultVector;
  }

  Vector &operator*(const double &scaleFactor) {
    for (unsigned index = 0; index < _vector.size(); ++index)
      _vector[index] *= scaleFactor;
    return *this;
  }

  friend Vector operator*(const double &scaleFactor, Vector vector) {
    for (unsigned index = 0; index < vector.size(); ++index)
      vector[index] *= scaleFactor;
    return vector;
  }

  double operator*(const Vector &other) {
    assert(_isRowVector && !other._isRowVector && "first vector must be a row vector, second must be a column vector");
    double sum = 0.0;
    for (unsigned i = 0; i < _vector.size(); ++i)
      sum += _vector[i] * other._vector[i];
    return sum;
  }
  
  friend std::ostream &operator<<(std::ostream &out, const Vector &vector) {
    out << "( ";
    for (unsigned index = 0; index < vector.size(); ++index)
      out << vector[index] << " ";
    out << ")";
    return out;
  }

private:
  VectorType _vector;
  bool _isRowVector = false;
};

} // namespace linearAlgebraLib