#!/bin/bash

rm -rf build
mkdir -p build

# compile source files into object code
g++ -c -fPIC -g -O0 -Wall -Wextra -I. linearAlgebraLib/src/sparseMatrixCSR.cpp -o build/sparseMatrixCSR.o
g++ -c -fPIC -g -O0 -Wall -Wextra -I. linearAlgebraLib/src/vector.cpp -o build/vector.o
g++ -c -fPIC -g -O0 -Wall -Wextra -I. linearAlgebraLib/src/linearAlgebraSolverBase.cpp -o build/linearAlgebraSolver.o
g++ -c -fPIC -g -O0 -Wall -Wextra -I. linearAlgebraLib/src/conjugateGradient.cpp -o build/conjugateGradient.o
g++ -c -g -O0 -Wall -Wextra -I. main.cpp -o build/main.o

# link object files into dynamic library
g++ -shared -g -O0 -Wall -Wextra -I. -o build/libDynamicLinearAlgebra.so build/sparseMatrixCSR.o build/vector.o build/linearAlgebraSolver.o build/conjugateGradient.o

# compile main function and link library into executable
g++ -g -O0 -Wall -Wextra -I. build/main.o -o build/dynamicLibExample -Lbuild -Wl,-rpath=build -lDynamicLinearAlgebra

# remove object files
rm build/*.o

# run
echo "Running dynamic library example"
./build/dynamicLibExample