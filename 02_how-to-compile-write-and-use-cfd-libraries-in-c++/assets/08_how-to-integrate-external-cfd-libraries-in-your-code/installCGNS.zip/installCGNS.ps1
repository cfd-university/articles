# make sure correct powershell is set up
Write-Host "To ensure you can compile 64-bit applications, you'll need to create a new PowerShell shortcut."
Write-Host "Step 1:"
Write-Host "- Go to C:\ProgramData\Microsoft\Windows\Start Menu\Programs\Visual Studio 2022\Visual Studio Tools (change the version number if needed)."
Write-Host "Step 2:"
Write-Host "- Create a copy of Developer PowerShell for VS 2022 (change version number if needed)."
Write-Host "Step 3:"
Write-Host "- Name it Developer PowerShell for VS 2022 - x64"
Write-Host "Step 4:"
Write-Host "- Right click on it and append -DevCmdArguments '-arch=x64' to the target, i.e. you have something like:"
Write-Host "C:\Windows\SysWOW64\WindowsPowerShell\v1.0\powershell.exe -noe -c &{Import-Module C:\Program Files\Microsoft Visual Studio\2022\Community\Common7\Tools\Microsoft.VisualStudio.DevShell.dll; Enter-VsDevShell 1eb5d1ab -DevCmdArguments '-arch=x64'}"
Write-Host "Step 5:"
Write-Host "- Launch this script in the new Developer PowerShell for VS 2022 - x64."

Read-Host -Prompt "Press Enter to continue"

# specify library versions to be installed
$ZLIB_VERSION = "1.3"
$HDF5_VERSION = "1.14.3"
$CGNS_VERSION = "4.4.0"

# specify install directory (IMPORTANT: do not remove trailing forward slash, e.g. \)
$INSTALL_DIR = "C:\libraries\"
New-Item -ItemType Directory -Force -Path $INSTALL_DIR

# exit upon error
$ErrorActionPreference = "Stop"

# check that required programs are installed
if (!(Get-Command "cmake" -ErrorAction SilentlyContinue)) {
    Write-Error "Error: cmake is not installed or found."
    exit 1
}

if (!(Get-Command "cl" -ErrorAction SilentlyContinue)) {
    Write-Error "Error: Visual Studio C++ compiler (cl.exe) is not installed or found."
    exit 1
}

# create install directory
New-Item -ItemType Directory -Force -Path $INSTALL_DIR

# replace . in library versions
$ZLIB_VERSION_CLEAN = $ZLIB_VERSION -replace "\.", ""
$HDF5_VERSION_CLEAN = $HDF5_VERSION -replace "\.", "_"

# construct dynamic download links
$ZLIB_URL = "https://github.com/madler/zlib/releases/download/v$ZLIB_VERSION/zlib$ZLIB_VERSION_CLEAN.zip"
$HDF5_URL = "https://github.com/HDFGroup/hdf5/releases/download/hdf5-$HDF5_VERSION_CLEAN/hdf5-$HDF5_VERSION_CLEAN.zip"
$CGNS_URL = "https://github.com/CGNS/CGNS/archive/refs/tags/v$CGNS_VERSION.zip"

# check if libraries are already downloaded, if not, use Invoke-WebRequest to download them
if (!(Test-Path "zlib-$ZLIB_VERSION_CLEAN")) {
    Invoke-WebRequest -Uri $ZLIB_URL -OutFile "zlib-$ZLIB_VERSION_CLEAN.zip"
    Expand-Archive -LiteralPath "zlib-$ZLIB_VERSION_CLEAN.zip"
}

if (!(Test-Path "hdf5-$HDF5_VERSION_CLEAN")) {
    Invoke-WebRequest -Uri $HDF5_URL -OutFile "hdf5-$HDF5_VERSION_CLEAN.zip"
    Expand-Archive -LiteralPath "hdf5-$HDF5_VERSION_CLEAN.zip"
}

if (!(Test-Path "CGNS-$CGNS_VERSION")) {
    Invoke-WebRequest -Uri $CGNS_URL -OutFile "CGNS-$CGNS_VERSION.zip"
    Expand-Archive -LiteralPath "CGNS-$CGNS_VERSION.zip"
}

# set number of CPU cores
$NUM_CPU = (Get-WmiObject -Class Win32_ComputerSystem).NumberOfLogicalProcessors

# compile and install zlib
Set-Location zlib-$ZLIB_VERSION_CLEAN\zlib-$ZLIB_VERSION
New-Item -ItemType Directory -Force -Path build
Set-Location build
cmake -DCMAKE_BUILD_TYPE=Release -DCMAKE_INSTALL_PREFIX="$INSTALL_DIR" ..
cmake --build . --target install --config Release -j "$NUM_CPU"
Set-Location ..\..\..

# compile and install hdf5
Set-Location hdf5-$HDF5_VERSION_CLEAN\hdfsrc
New-Item -ItemType Directory -Force -Path build
Set-Location build
cmake -DCMAKE_BUILD_TYPE=Release -DCMAKE_INSTALL_PREFIX="$INSTALL_DIR" -DZLIB_INCLUDE_DIR="$INSTALL_DIR\include" -DZLIB_LIBRARY_RELEASE="$INSTALL_DIR\lib\zlib.lib" ..
cmake --build . --target install --config Release -j "$NUM_CPU"
Set-Location ..\..\..

# compile and install cgns
Set-Location CGNS-$CGNS_VERSION\CGNS-$CGNS_VERSION
New-Item -ItemType Directory -Force -Path build
Set-Location build
cmake -DCMAKE_BUILD_TYPE=Release -DCMAKE_INSTALL_PREFIX="$INSTALL_DIR" -DHDF5_C_INCLUDE_DIR="$INSTALL_DIR\include" -DHDF5_hdf5_LIBRARY_RELEASE="$INSTALL_DIR\lib\hdf5.lib" ..
cmake --build . --target install --config Release -j "$NUM_CPU"
Set-Location ..\..\..

# Test that the CGNS library was installed successfully
$SAMPLE_CGNS_PROGRAM = @"
#include <iostream>
#include "cgnslib.h"

int main() {
    int file_id;
    float version;
    cg_open("test.cgns", CG_MODE_WRITE, &file_id);
    cg_version(file_id, &version);
    std::cout << "CGNS library version detected in C++ test code: " << version << std::endl;
    std::cout << "If you see a version printed above, the installation was successful." << std::endl;
    return 0;
}
"@

# Write the C++ test program to a file
$SAMPLE_CGNS_PROGRAM | Out-File -FilePath cgnsTest.cpp -Encoding ASCII

Write-Host ""
Write-Host "Test CGNS installation"
Write-Host ""

# copy dynamic libraries of HDF5 and zlib into current directory
Copy-Item "$INSTALL_DIR\bin\zlib.dll" -Destination .
Copy-Item "$INSTALL_DIR\bin\hdf5.dll" -Destination .

cl.exe /nologo /EHsc /I "${INSTALL_DIR}include" /c cgnsTest.cpp /Fo"cgnsTest.obj"
cl.exe /nologo /EHsc cgnsTest.obj /Fe"cgnsTest.exe" /link /MACHINE:x64 /LIBPATH:"${INSTALL_DIR}lib" cgns.lib hdf5.lib msvcrt.lib libcmt.lib
.\cgnsTest.exe

# clean up
Remove-Item .\cgnsTest.obj
Remove-Item .\test.cgns
Remove-Item .\cgnsTest.exe

### output information to screen

Write-Host ""
Write-Host "##########################################"
Write-Host ""
Write-Host "The CGNS library has been installed in $INSTALL_DIR"
Write-Host ""
Write-Host "- The static library is located at ${INSTALL_DIR}lib\cgns.lib"
Write-Host "- The dynamic library is located at ${INSTALL_DIR}lib\cgnsdll.lib"
Write-Host "- The header file is located at ${INSTALL_DIR}include\cgnslib.h"
Write-Host ""
Write-Host "- To use any of the CGNS tools, navigate to ${INSTALL_DIR}bin"
Write-Host "- To inspect a cgns file, use ${INSTALL_DIR}bin\cgnslist.exe CGNS_file.cgns"
Write-Host ""
Write-Host "- A minimal program that tests the CGNS installation has been written to cgnsTest.cpp"
Write-Host "  To compile it yourself, use the following commands"
Write-Host ""
Write-Host "  Copy-Item "${INSTALL_DIR}bin\zlib.dll" -Destination ."
Write-Host "  Copy-Item "${INSTALL_DIR}bin\hdf5.dll" -Destination ."
Write-Host "  cl.exe /nologo /EHsc /I `"${INSTALL_DIR}include`" /c cgnsTest.cpp /Fo`"cgnsTest.obj`""
Write-Host "  cl.exe /nologo /EHsc cgnsTest.obj /Fe`"cgnsTest.exe`" /link /MACHINE:x64 /LIBPATH:`"${INSTALL_DIR}lib`" cgns.lib hdf5.lib msvcrt.lib libcmt.lib"
Write-Host ""
Write-Host "- You can now run the cgnsTest program to test the installation"
Write-Host "  .\cgnsTest.exe"
Write-Host ""
Write-Host "##########################################"
Write-Host ""
