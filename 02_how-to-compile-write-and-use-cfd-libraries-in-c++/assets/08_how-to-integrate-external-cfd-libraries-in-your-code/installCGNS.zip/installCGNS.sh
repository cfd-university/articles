#!/bin/bash

# specify library versions to be installed
ZLIB_VERSION=1.3.1
HDF5_VERSION=1.14.3
CGNS_VERSION=4.4.0

# specify install directory (IMPORTANT: do not remove trailing forward slash, e.g. /)
# you can leave it as it is if you want to install CGNS in your home directory
INSTALL_DIR=~/libs/
mkdir -p $INSTALL_DIR

###########################
### do not edit lines below
###########################

# exit upon error
set -e

# check that required programs are installed
if ! [ -x "$(command -v wget)" ]; then
  echo 'Error: wget is not installed.' >&2
  echo 'Please install wget first. (e.g. on ubuntu: sudo apt install -y wget)'
  exit 1
fi

if ! [ -x "$(command -v cmake)" ]; then
  echo 'Error: cmake is not installed.' >&2
  echo 'Please install cmake first. (e.g. on ubuntu: sudo apt install -y cmake)'
  exit 1
fi

if ! [ -x "$(command -v ninja)" ]; then
  echo 'Error: ninja is not installed.' >&2
  echo 'Please install ninja first. (e.g. on ubuntu: sudo apt install -y ninja-build)'
  exit 1
fi

if ! [ -x "$(command -v g++)" ]; then
  echo 'Error: g++ is not installed.' >&2
  echo 'Please install g first. (e.g. on ubuntu: sudo apt install -y build-essential)'
  exit 1
fi

# create install directory
mkdir -p $INSTALL_DIR

# replace . with _ in library versions
HDF5_VERSION=${HDF5_VERSION//./_}

# construct dynamic download links
ZLIB_URL=https://github.com/madler/zlib/releases/download/v$ZLIB_VERSION/zlib-$ZLIB_VERSION.tar.gz
HDF5_URL=https://github.com/HDFGroup/hdf5/releases/download/hdf5-$HDF5_VERSION/hdf5-$HDF5_VERSION.tar.gz
CGNS_URL=https://github.com/CGNS/CGNS/archive/refs/tags/v$CGNS_VERSION.tar.gz

# check if libraries are already downloaded, if not, use wget to download them
if [ ! -d "zlib-$ZLIB_VERSION/" ]; then
  wget $ZLIB_URL
  tar -zxf zlib-$ZLIB_VERSION.tar.gz
fi

if [ ! -d "hdfsrc/" ]; then
  wget $HDF5_URL
  tar -zxf hdf5-$HDF5_VERSION.tar.gz
fi

if [ ! -d "CGNS-$CGNS_VERSION/" ]; then
  wget $CGNS_URL
  mv v$CGNS_VERSION.tar.gz CGNS-$CGNS_VERSION.tar.gz
  tar -zxf CGNS-$CGNS_VERSION.tar.gz
fi

# set number of CPU cores
NUM_CPU=$(nproc)

# compile and install zlib
cd zlib-$ZLIB_VERSION
mkdir -p build && cd build
cmake -DCMAKE_BUILD_TYPE=Release -DCMAKE_INSTALL_PREFIX=$INSTALL_DIR -G Ninja ..
cmake --build . --target install --config Release -j $NUM_CPU
cd ../../

# compile and install hdf5
cd hdfsrc/
mkdir -p build && cd build
cmake -DCMAKE_BUILD_TYPE=Release -DCMAKE_INSTALL_PREFIX=$INSTALL_DIR -DZLIB_INCLUDE_DIR=$INSTALL_DIR/include -DZLIB_LIBRARY_RELEASE=$INSTALL_DIR/lib/libz.so -G Ninja ..
cmake --build . --target install --config Release -j $NUM_CPU
cd ../../

# compile and install cgns
cd CGNS-$CGNS_VERSION
mkdir -p build && cd build
cmake -DCMAKE_BUILD_TYPE=Release -DCMAKE_INSTALL_PREFIX=$INSTALL_DIR -DHDF5_C_INCLUDE_DIR=$INSTALL_DIR/include -DHDF5_hdf5_LIBRARY_RELEASE=$INSTALL_DIR/lib/libhdf5.so -G Ninja ..
cmake --build . --target install --config Release -j $NUM_CPU
cd ../../

# test that the CGNS library was installed successfully

SAMPLE_CGNS_PROGRAM='
#include <iostream>
#include "cgnslib.h"

int main() {
  int file_id;
  float version;
  cg_open("test.cgns", CG_MODE_WRITE, &file_id);
  cg_version(file_id, &version);
  std::cout << "CGNS library version detected in C++ test code: " << version << std::endl;
  std::cout << "If you see a version printed above, the installation was successful." << std::endl;
  return 0;
}
'
echo "$SAMPLE_CGNS_PROGRAM" > cgnsTest.cpp

echo ""
echo "Test CGNS installation"
echo ""

g++ -I${INSTALL_DIR}/include -c -o cgnsTest.o cgnsTest.cpp
g++ -o cgnsTest cgnsTest.o -L${INSTALL_DIR}/lib -lcgns
./cgnsTest

# clean up
rm cgnsTest cgnsTest.o

### output information to screen

echo ""
echo "##########################################"
echo ""
echo "The CGNS library has been installed in $INSTALL_DIR"
echo ""
echo "- The static library is located at ${INSTALL_DIR::-1}/lib/libcgns.a"
echo "- The dynamic library is located at ${INSTALL_DIR::-1}/lib/libcgns.so"
echo "- The header file is located at ${INSTALL_DIR::-1}/include/cgnslib.h"
echo ""
echo "- To use any of the CGNS tools, navigate to ${INSTALL_DIR}bin"
echo "- To inspect a cgns file, use ${INSTALL_DIR::-1}/bin/cgnslist CGNS_file.cgns"
echo ""
echo "- A minimal program that tests the CGNS installation has been written to cgnsTest.cpp"
echo "  To compile it yourself, use the following commands"
echo "  g++ -I${INSTALL_DIR::-1}/include -c -o cgnsTest.o cgnsTest.cpp"
echo "  g++ -o cgnsTest cgnsTest.o -L${INSTALL_DIR::-1}/lib -lcgns"
echo ""
echo "- You can now run the cgnsTest program to test the installation"
echo "  ./cgnsTest"
echo ""
echo "##########################################"
echo ""
